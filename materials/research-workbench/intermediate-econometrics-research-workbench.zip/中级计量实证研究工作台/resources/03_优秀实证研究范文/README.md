# 优秀实证研究范文

本目录按**四类研究设计路径**汇集了教师精选的前沿工作论文与已发表标杆研究，供学生对照学习“不同路径的研究问题如何落地、非强因果论文靠什么立住、以及数据/测度/设计边界如何写透”。

> **使用与版权说明**：本目录内直接附带的 **7 份 PDF 为公开发布的工作论文（Working Paper）副本**，仅供本课程教学研读，引用前请回到作者主页或 NBER/SSRN 页面核对最新修订版与正式发表信息；已正式见刊的中英文期刊论文（如 *PNAS*、《经济学（季刊）》《管理世界》《中国工业经济》）受期刊版权约束不直接分发 PDF，请通过学校图书馆、CNKI 或 DOI 自行下载正文。采用范文中的具体方案前，仍须论证其对当前课题的适用性；公共资源查阅与添加方式见 [公共资源索引](../README.md)。

---

## 一、公开工作论文副本（本地可直接打开）

| 路径分类 | 论文作者与年份 | 论文标题与工作论文系列 | 核心数据与方法亮点 | 本地 PDF |
|---|---|---|---|---|
| **典型事实与新现象刻画** | Brynjolfsson, Chandar & Chen (2025) | *Canaries in the Coal Mine? Six Facts about the Recent Employment Effects of Artificial Intelligence* (Stanford Digital Economy Lab WP) | 不靠单一政策冲击，用高频 ADP 工资册 + AI 暴露度五分位与“自动化 vs. 增强”分类，直接以“六个结构化典型事实”立住全文 | [Brynjolfsson_Chandar_Chen_2025_Canaries_Coal_Mine.pdf](Brynjolfsson_Chandar_Chen_2025_Canaries_Coal_Mine.pdf) |
| **数据测度与代表性校准** | Dalton, Kahn & Mueller (2026) | *Do Online Job Postings Capture Job Vacancies?* (NBER WP No. 35697) | 专门核验“在线招聘广告多大程度上代表真实职位空缺”，是学习样本代表性与测度偏差校准的极佳范本（对应第 3 章） | [Dalton_Kahn_Mueller_2026_Online_Job_Postings_NBER_w35697.pdf](Dalton_Kahn_Mueller_2026_Online_Job_Postings_NBER_w35697.pdf) |
| **理论 + 实证（多重预测闭环）** | Eisfeldt, Schubert & Zhang (2026) | *Generative AI and Firm Values* (NBER WP No. 31222) | 提出“核心任务 vs. 补充任务 + 数据资产互补”框架，推导股价、岗位、工资、毛利率等 5 条互锁假说，跨多源数据交叉印证 | [Eisfeldt_Schubert_Zhang_2026_Generative_AI_Firm_Values_NBER_w31222.pdf](Eisfeldt_Schubert_Zhang_2026_Generative_AI_Firm_Values_NBER_w31222.pdf) |
| **理论 + 实证（经典理论焕新）** | Arkolakis, Kwon, Russel, Shi & Yang (2026) | *Gambling for Goals* (SSRN No. 5761702) | 用 Friedman-Savage (1948) 效用动机解释买房/结婚目标遥不可及下的金融冒险，结合原创问卷与百万级信用/电信/卡交易面板检验多维预测 | [Arkolakis_et_al_2026_Gambling_for_Goals_SSRN_5761702.pdf](Arkolakis_et_al_2026_Gambling_for_Goals_SSRN_5761702.pdf) |
| **理论 + 结构实证（进阶观摩）** | Egan, Russel, Shi & Yao (2026) | *Competition in Generative AI: Evidence from Consumer Demand* (NBER WP No. 35953) | 离散选择均衡定价理论 + 消费卡交易面板，示范如何区分消费者相关偏好与产品互补性 | [Egan_Russel_Shi_Yao_2026_Competition_Generative_AI_NBER_w35953.pdf](Egan_Russel_Shi_Yao_2026_Competition_Generative_AI_NBER_w35953.pdf) |
| **因果识别（中国情境 DID）** | Strömberg, Lei & Wu (2026) | *The Generative AI Learning Penalty: Evidence from Chinese Secondary Education* (SSRN No. 6868618) | 2.68 万名中国初高中生 30 个月面板 + 交错 DID：AI 让作业分升 18%、耗时降 30%，却令闭卷成绩降 18%—24%（第 4—5 章关键反直觉案例） | [Stromberg_Lei_Wu_2026_GenerativeAI_Learning_Penalty_SSRN_6868618.pdf](Stromberg_Lei_Wu_2026_GenerativeAI_Learning_Penalty_SSRN_6868618.pdf) |
| **因果识别（Shift-Share IV）** | Alvarez, Argente, Chow & Van Patten (2026) | *Data Centers and Local Economies in the Age of AI: A Shift-Share Approach* (NBER WP No. 35194) | 双工具 Bartik/Shift-share IV 评估 AI 基础设施对县级就业、房价与电价的双向效应 | [Alvarez_et_al_2026_Data_Centers_ShiftShare_NBER_w35194.pdf](Alvarez_et_al_2026_Data_Centers_ShiftShare_NBER_w35194.pdf) |

---

## 二、已发表重要期刊对照（请通过学校数据库或 DOI 下载原文）

| 路径 / 主题 | 作者与发表期刊 | 核心参考价值 | 检索入口 / DOI |
|---|---|---|---|
| **典型事实 + 信息实验** | Humlum & Vestergaard (2025), *PNAS*, 122(1) — *The Unequal Adoption of ChatGPT Exacerbates Existing Inequalities among Workers* | 1.8 万名工人调查 + 行政登记数据刻画不平等采纳，再配随机信息实验检验约束，是“描述发现 + 轻量实验”的典范 | DOI: `10.1073/pnas.2414972121` |
| **本土测度 + 样本边界披露** | 莫怡青、王安琪、李力行 (2026), 《经济学（季刊）》—《人工智能技术重塑劳动技能需求——基于在线招聘数据的发现》 | 依托前程无忧构建本土 5 大类 18 小类技能体系，并坦诚检验并披露在线招聘对低技能样本覆盖不足的代表性局限 | DOI: `10.13821/j.cnki.ceq.2026.03.08` |
| **方法规范：控制变量** | 张子尧、黄炜 (2025), 《管理世界》—《实证研究中的控制变量选择：原理与原则》 | 讲透“好控制 vs. 坏控制（对撞/中介）”与选择性筛选（p-hacking）边界，可直接对照第 3—5 章精读 | DOI: `10.19744/j.cnki.11-1235/f.2025.0136` |
| **方法规范：机制检验** | 江艇 (2022), 《中国工业经济》—《因果推断经验研究中的中介效应与调节效应》 | 阐明经济学机制检验为何不宜照搬传统逐步回归中介效应模型，可直接对照第 5 章 5.4 节精读 | CNKI 检索篇名即可获取 |
