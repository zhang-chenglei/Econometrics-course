"""出「理论分析 / 理论+实证 / 计量实证」的对比图（中文七刊 vs 英文五刊）。"""
from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.font_manager as fm
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent
FIG = ROOT / "figures"
FIG.mkdir(parents=True, exist_ok=True)

ORDER = ["理论分析", "理论+实证", "计量实证"]
COLORS = {"理论分析": "#3f5c78", "理论+实证": "#c2606f", "计量实证": "#941f3a"}
EN_NAMES = {"AER": "AER", "QJE": "QJE", "JPE": "JPE", "ECMA": "Econometrica", "RESTUD": "ReStud"}


def font() -> str:
    available = {f.name for f in fm.fontManager.ttflist}
    for name in ("Songti SC", "STSong", "Heiti SC", "PingFang SC", "Arial Unicode MS"):
        if name in available:
            return name
    raise SystemExit("no cjk font")


def load(path: Path, journal_key: str) -> dict[str, Counter]:
    out: dict[str, Counter] = defaultdict(Counter)
    for row in csv.DictReader(path.open(encoding="utf-8-sig")):
        out[row[journal_key]][row["paper_type"]] += 1
    return out


def main() -> None:
    plt.rcParams["font.family"] = font()
    zh = load(ROOT / "data" / "titles_coded.csv", "journal_name")
    en = load(ROOT / "data" / "en_titles_coded.csv", "journal")

    labels = list(zh) + [EN_NAMES[k] for k in en]
    data = list(zh.values()) + list(en.values())

    fig, ax = plt.subplots(figsize=(8.6, 5.4))
    left = [0.0] * len(labels)
    for t in ORDER:
        vals = [c[t] / sum(c.values()) * 100 if sum(c.values()) else 0 for c in data]
        ax.barh(labels, vals, left=left, color=COLORS[t], label=t, height=0.62)
        left = [a + b for a, b in zip(left, vals)]
    for i, c in enumerate(data):
        ax.text(101, i, f"n={sum(c.values())}", va="center", fontsize=8, color="#555")

    ax.set_xlim(0, 100)
    ax.invert_yaxis()
    ax.set_xlabel("占该刊题目比例（%）")
    ax.axhline(len(zh) - 0.5, color="#999", lw=0.8, ls="--")
    ax.legend(ncol=3, fontsize=9, frameon=False, loc="lower center", bbox_to_anchor=(0.5, -0.16))
    ax.set_title("理论分析 / 理论+实证 / 计量实证：中文七刊与英文五刊", fontsize=13, pad=12)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    out = FIG / "fig5_paper_type.png"
    fig.savefig(out, dpi=200)
    plt.close(fig)

    # 汇总数字
    zh_total = Counter()
    for c in zh.values():
        zh_total.update(c)
    en_total = Counter()
    for c in en.values():
        en_total.update(c)
    print("中文七刊：", {k: f"{v} ({v / sum(zh_total.values()) * 100:.1f}%)" for k, v in zh_total.items()})
    print("英文五刊：", {k: f"{v} ({v / sum(en_total.values()) * 100:.1f}%)" for k, v in en_total.items()})
    print("图 ->", out)


if __name__ == "__main__":
    main()
