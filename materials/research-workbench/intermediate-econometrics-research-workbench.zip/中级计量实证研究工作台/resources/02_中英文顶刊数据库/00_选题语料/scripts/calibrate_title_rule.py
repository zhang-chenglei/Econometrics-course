"""用 NAPSTIC 2024 的摘要做校准：题目判读 vs 摘要判读 的一致率。"""
from __future__ import annotations

import csv
import json
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

ZH_THEORY_T = ("理论", "模型", "框架", "均衡", "博弈", "机制设计", "述评", "研究综述",
               "逻辑", "范式", "命题")
ZH_EMP_T = ("检验", "证据", "数据", "实证", "案例", "测度", "测算", "估计", "评估",
            "影响", "效应", "作用", "回归", "调查", "实验", "经验")

ABS_THEORY = ("构建", "建立一个", "理论模型", "一般均衡", "命题", "推导", "证明",
              "模型刻画", "理论分析")
ABS_EMP = ("实证", "数据", "样本", "回归", "估计", "检验", "检验结果", "识别",
           "面板", "调查", "实验", "本文发现", "结果表明", "稳健")


def from_title(title: str) -> str:
    th = any(w in title for w in ZH_THEORY_T)
    em = any(w in title for w in ZH_EMP_T)
    return "理论+实证" if th and em else ("理论分析" if th else "计量实证")


def from_abstract(title: str, abstract: str) -> str:
    th = any(w in abstract for w in ABS_THEORY) or any(w in title for w in ZH_THEORY_T)
    em = any(w in abstract for w in ABS_EMP) or any(w in title for w in ZH_EMP_T)
    return "理论+实证" if th and em else ("理论分析" if th else "计量实证")


def main() -> None:
    abstracts: dict[str, str] = {}
    for path in sorted((ROOT / "raw" / "napstic").glob("*.json")):
        for item in json.loads(path.read_text(encoding="utf-8")):
            if isinstance(item, dict) and item.get("abstract"):
                abstracts[re.sub(r"\s+", "", item.get("title", ""))] = item["abstract"]

    rows = [r for r in csv.DictReader((ROOT / "data" / "titles_coded.csv").open(encoding="utf-8-sig"))
            if r["year"] == "2024"]
    pairs = [(r["title"], abstracts[re.sub(r"\s+", "", r["title"])])
             for r in rows if re.sub(r"\s+", "", r["title"]) in abstracts]

    agree = 0
    conf = Counter()
    for title, abstract in pairs:
        a, b = from_title(title), from_abstract(title, abstract)
        conf[(a, b)] += 1
        agree += a == b

    print(f"可比对 {len(pairs)} 篇（2024 年有摘要者）")
    print(f"题目判读与摘要判读一致 {agree} 篇，一致率 {agree / len(pairs) * 100:.1f}%")
    print("\n混淆（行=题目判读，列=摘要判读）：")
    for (a, b), n in sorted(conf.items(), key=lambda x: -x[1]):
        if a != b:
            print(f"  题目判 {a} → 摘要判 {b}: {n}")


if __name__ == "__main__":
    main()
