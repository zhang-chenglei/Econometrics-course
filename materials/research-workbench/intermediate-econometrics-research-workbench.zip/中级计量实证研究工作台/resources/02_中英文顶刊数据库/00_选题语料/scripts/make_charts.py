"""用编码后的题录出四张图，供第12讲使用。"""
from __future__ import annotations

import csv
import warnings
from collections import Counter, defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.font_manager as fm
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "titles_coded.csv"
FIG = ROOT / "figures"
FIG.mkdir(parents=True, exist_ok=True)

TYPES = ["因果/效应", "关系/机制", "理论/模型", "案例研究", "测量/构造", "方法/综述", "预测", "其他"]
COLORS = ["#941f3a", "#c2606f", "#e0a3ac", "#7a8b99", "#9fb3c8", "#c9d6df", "#d9c7a3", "#dcdcdc"]
JOURNALS = ["经济研究", "管理世界", "经济学（季刊）", "中国工业经济", "数量经济技术经济研究", "世界经济", "金融研究"]


def cjk_font() -> str:
    prefer = ["Songti SC", "STSong", "Heiti SC", "PingFang SC", "Arial Unicode MS"]
    available = {f.name for f in fm.fontManager.ttflist}
    for name in prefer:
        if name in available:
            return name
    raise SystemExit("没有可用的中文字体")


def load() -> list[dict]:
    return list(csv.DictReader(DATA.open(encoding="utf-8-sig")))


def chart_type_by_journal(rows: list[dict], font: str) -> None:
    plt.rcParams["font.family"] = font
    counts = defaultdict(Counter)
    totals = Counter()
    for r in rows:
        counts[r["journal_name"]][r["qtype"]] += 1
        totals[r["journal_name"]] += 1

    fig, ax = plt.subplots(figsize=(9.2, 5.2))
    left = [0] * len(JOURNALS)
    for t, c in zip(TYPES, COLORS):
        vals = [counts[j][t] / totals[j] * 100 if totals[j] else 0 for j in JOURNALS]
        ax.barh(JOURNALS, vals, left=left, color=c, label=t, height=0.62)
        left = [a + b for a, b in zip(left, vals)]
    ax.set_xlabel("占该刊题目比例（%）")
    ax.set_xlim(0, 100)
    ax.invert_yaxis()
    ax.legend(ncol=4, fontsize=8, loc="lower center", bbox_to_anchor=(0.5, -0.32), frameon=False)
    ax.set_title("七刊题目类型构成（2024—2026）", fontsize=13, pad=12)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(FIG / "fig1_type_by_journal.png", dpi=200)
    plt.close(fig)


def chart_type_by_year(rows: list[dict], font: str) -> None:
    plt.rcParams["font.family"] = font
    years = ["2024", "2025", "2026"]
    counts = defaultdict(Counter)
    totals = Counter()
    for r in rows:
        counts[r["year"]][r["qtype"]] += 1
        totals[r["year"]] += 1

    fig, ax = plt.subplots(figsize=(7.6, 4.2))
    x = range(len(years))
    bottom = [0] * len(years)
    for t, c in zip(TYPES, COLORS):
        vals = [counts[y][t] / totals[y] * 100 if totals[y] else 0 for y in years]
        ax.bar(list(x), vals, bottom=bottom, color=c, label=t, width=0.52)
        bottom = [a + b for a, b in zip(bottom, vals)]
    ax.set_xticks(list(x))
    ax.set_xticklabels([f"{y}年（n={totals[y]}）" for y in years])
    ax.set_ylabel("占比（%）")
    ax.legend(ncol=4, fontsize=8, loc="lower center", bbox_to_anchor=(0.5, -0.28), frameon=False)
    ax.set_title("题目类型的时间分布", fontsize=13, pad=10)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(FIG / "fig2_type_by_year.png", dpi=200)
    plt.close(fig)


def chart_features(rows: list[dict], font: str) -> None:
    plt.rcParams["font.family"] = font
    feats = [
        ("has_dash_subtitle", "副标题（——/：）"),
        ("is_question", "问句"),
        ("has_policy_word", "含政策专名"),
        ("has_number", "含数字"),
    ]
    totals = Counter(r["journal_name"] for r in rows)
    fig, ax = plt.subplots(figsize=(9.2, 4.8))
    width = 0.2
    xs = range(len(JOURNALS))
    for k, (key, label) in enumerate(feats):
        vals = [sum(int(r[key]) for r in rows if r["journal_name"] == j) / totals[j] * 100
                if totals[j] else 0 for j in JOURNALS]
        ax.bar([x + (k - 1.5) * width for x in xs], vals, width=width, label=label)
    ax.set_xticks(list(xs))
    ax.set_xticklabels(JOURNALS, fontsize=9)
    ax.set_ylabel("占比（%）")
    ax.legend(fontsize=9, frameon=False, ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.12))
    ax.set_title("题目句式特征", fontsize=13, pad=26)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(FIG / "fig3_features.png", dpi=200)
    plt.close(fig)


def chart_length(rows: list[dict], font: str) -> None:
    plt.rcParams["font.family"] = font
    lens = [int(r["len"]) for r in rows]
    fig, ax = plt.subplots(figsize=(7.4, 4.0))
    ax.hist(lens, bins=range(0, 65, 2), color="#941f3a", alpha=0.85, edgecolor="white")
    median = sorted(lens)[len(lens) // 2]
    ax.axvline(median, color="#333", ls="--", lw=1)
    ax.text(median + 1, ax.get_ylim()[1] * 0.88, f"中位数 {median} 字", fontsize=10)
    ax.set_xlabel("题目字数")
    ax.set_ylabel("篇数")
    ax.set_title(f"题目长度分布（全部 {len(rows)} 篇）", fontsize=13, pad=10)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig(FIG / "fig4_length.png", dpi=200)
    plt.close(fig)


def export_examples(rows: list[dict]) -> None:
    out = ROOT / "data" / "examples_by_type.csv"
    with out.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["类型", "期刊", "年", "题名"])
        for t in TYPES:
            picks = [r for r in rows if r["qtype"] == t][:12]
            for r in picks:
                writer.writerow([t, r["journal_name"], r["year"], r["title"]])
    print("examples ->", out)


def main() -> None:
    font = cjk_font()
    rows = load()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        chart_type_by_journal(rows, font)
        chart_type_by_year(rows, font)
        chart_features(rows, font)
        chart_length(rows, font)
        missing = [w for w in caught if "missing from font" in str(w.message).lower()
                   or "Glyph" in str(w.message)]
    export_examples(rows)
    print("字体:", font, "| 缺字警告:", len(missing))
    for f in sorted(FIG.glob("*.png")):
        print(f.name, f.stat().st_size // 1024, "KB")


if __name__ == "__main__":
    main()
