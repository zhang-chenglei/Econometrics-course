"""合并 NCPSSD / NAPSTIC / 世界经济官网抓取结果，去噪去重并补全字段，输出 data/titles_all.csv。"""
from __future__ import annotations

import csv
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
DATA.mkdir(parents=True, exist_ok=True)

NAMES = {
    "jjyj": "经济研究",
    "glsj": "管理世界",
    "jjx": "经济学（季刊）",
    "zggyjj": "中国工业经济",
    "sljjjsjjyj": "数量经济技术经济研究",
    "sjjj": "世界经济",
    "jryj": "金融研究",
}

SKIP_WORDS = (
    "征稿启事", "征文启事", "征稿", "致谢", "目录", "总目录", "要目", "稿约", "本刊声明", "声明", "启事",
    "公告", "通知", "名单", "优秀论文", "最佳论文", "招聘", "诚聘", "培训", "知识服务", "征文", "评选",
    "资助计划", "写作的几点说明", "嘉言", "风清气正", "守正创新", "影响因子", "入选CSSCI", "再创佳绩",
    "数据编辑制度", "高影响力学术辑刊", "博士后论坛", "研讨会", "发展报告", "产业经济学科",
    "封面", "封底", "篇首语", "卷首语", "简介", "大讲堂", "电子刊", "征订", "稿酬", "敬告读者",
    "版权页", "编后记", "编者按", "会议综述", "座谈会", "学术动态", "新书", "书评", "悼念", "纪念",
    "致辞", "发言摘编", "笔谈", "简章", "China Economic Quarterly", "——评《", "—评《",
)

PUNCT_TRANS = str.maketrans("：？，（）“”‘’；！—－", ":?,()\"\"'';!--")


def clean(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).strip()


def norm_title_key(title: str) -> str:
    t = clean(title).translate(PUNCT_TRANS).lower()
    return re.sub(r"[\s\-:?,()\"'!;·《》]+", "", t)


def norm_pages(pages: str) -> str:
    p = clean(pages)
    return re.sub(r"页$", "", p)


def is_single_page(pages: str) -> bool:
    m = re.match(r"^(\d+)-(\d+)$", pages)
    return bool(m and m.group(1) == m.group(2))


def is_noise(title: str, authors: str, pages: str) -> bool:
    if not title or len(title) < 7:
        return True
    if any(w in title for w in SKIP_WORDS):
        return True
    if re.search(r"—+评《", title):
        return True
    if pages in ("0-0", "0") or any(x in pages for x in ("封", "插", "I0", "F0")):
        return True
    if not authors and (not pages or is_single_page(pages)):
        return True
    return False


def merge_record(bucket: dict[tuple, dict], key: tuple, cand: dict) -> None:
    cur = bucket.get(key)
    if cur is None:
        bucket[key] = cand
        return
    # Merge missing metadata from secondary source without losing primary fields
    for field in ("authors", "pages", "keywords", "abstract"):
        if not cur.get(field) and cand.get(field):
            cur[field] = cand[field]
    if cand.get("abstract") and len(cand["abstract"]) > len(cur.get("abstract", "")):
        cur["abstract"] = cand["abstract"]
    if len(cand.get("title", "")) > len(cur.get("title", "")) and "—" in cand["title"]:
        cur["title"] = cand["title"]


def main() -> None:
    rows: dict[tuple, dict] = {}
    dropped: list[tuple] = []

    def add(code: str, year: str, issue: int, title: str, authors: str, pages: str,
            keywords: str, abstract: str, source: str) -> None:
        title = clean(title)
        authors = clean(authors)
        pages = norm_pages(pages)
        keywords = clean(keywords)
        abstract = clean(abstract)
        if is_noise(title, authors, pages):
            dropped.append((NAMES.get(code, code), year, issue, pages, authors, title))
            return
        key = (code, str(year), norm_title_key(title))
        merge_record(rows, key, {
            "journal": code,
            "journal_name": NAMES.get(code, code),
            "year": int(year),
            "issue": int(issue),
            "title": title,
            "authors": authors,
            "pages": pages,
            "keywords": keywords,
            "abstract": abstract,
            "source": source,
        })

    # 1. 《世界经济》官网（含摘要/关键词/作者/页码）
    for path in sorted((ROOT / "raw" / "sjjj_web").glob("*.json")):
        _, year, issue = path.stem.split("_")[:3]
        for item in json.loads(path.read_text(encoding="utf-8")):
            add("sjjj", year, int(issue), item.get("title", ""), item.get("authors", ""),
                item.get("pages", ""), item.get("keywords", ""), item.get("abstract", ""), "sjjj_web")

    # 2. NAPSTIC（含 2024—2025 摘要/关键词/作者/页码）
    for path in sorted((ROOT / "raw" / "napstic").glob("*.json")):
        code, year, issue = path.stem.split("_")[:3]
        for raw in json.loads(path.read_text(encoding="utf-8")):
            if isinstance(raw, dict):
                add(code, year, int(issue), raw.get("title", ""), raw.get("authors", ""),
                    raw.get("pages", ""), raw.get("keywords", ""), raw.get("abstract", ""), "napstic")
            else:
                add(code, year, int(issue), str(raw), "", "", "", "", "napstic")

    # 3. NCPSSD（补齐 2024—2026 目录、作者与页码）
    for path in sorted((ROOT / "raw" / "ncpssd").glob("*.json")):
        code, year, issue = path.stem.split("_")[:3]
        for item in json.loads(path.read_text(encoding="utf-8")):
            add(code, year, int(issue), item.get("title", ""), item.get("authors", ""),
                item.get("pages", ""), "", "", "ncpssd")

    # 4. 补入 ncpssd_meta 中仅存的极少数有效摘要（过滤抓错的外壳文本）
    meta_dir = ROOT / "raw" / "ncpssd_meta"
    if meta_dir.exists():
        for path in sorted(meta_dir.glob("*.json")):
            code, year, _ = path.stem.split("_")[:3]
            for item in json.loads(path.read_text(encoding="utf-8")):
                ab = clean(item.get("abstract", ""))
                if len(ab) > 40 and "ISSN 基金资助" not in ab and "出 版 物" not in ab:
                    k = (code, str(year), norm_title_key(item.get("title", "")))
                    if k in rows and not rows[k]["abstract"]:
                        rows[k]["abstract"] = ab
                        if item.get("keywords") and not rows[k]["keywords"]:
                            rows[k]["keywords"] = clean(item["keywords"])

    out = DATA / "titles_all.csv"
    fields = ["journal", "journal_name", "year", "issue", "title", "authors", "pages", "keywords", "abstract", "source"]
    with out.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        for row in sorted(rows.values(), key=lambda r: (r["journal"], r["year"], r["issue"])):
            writer.writerow(row)

    print(f"剔除噪音/重复前非学术条目 {len(dropped)} 条，保留去重后 {len(rows)} 条 -> {out}")
    print(f"含摘要条目：{sum(1 for r in rows.values() if r['abstract'])} / {len(rows)}")
    print(f"缺作者条目：{sum(1 for r in rows.values() if not r['authors'])}；缺页码条目：{sum(1 for r in rows.values() if not r['pages'])}")


if __name__ == "__main__":
    main()
