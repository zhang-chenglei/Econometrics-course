"""逐页打开文章详情抓摘要（每页真实渲染，可靠但慢）。

用法：python3 collect_abstracts3.py <port> <刊代码> [<刊代码> ...]
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "raw" / "ncpssd_meta"
YEARS = ["2024", "2025", "2026"]

JOURNALS = {
    "jjyj": "gch=95645X",
    "glsj": "params=V2ZQZUlGQnRhM3lxVEkrUDlvU2gyYk1MTU40Z0V3dGZEUlUyK2doYnREUjhoNWV1eENEL0pTMU9hYytVRmw4Tg",
    "jjx": "params=S09tNUdmckdGRE9UaGFqRXlEUmZqN01MTU40Z0V3dGZEUlUyK2doYnREUmFEZnpkelJqMWRGbzFGd1oyQWpnSw",
    "zggyjj": "gch=93800A",
    "sljjjsjjyj": "gch=94503X",
    "sjjj": "gch=92713X",
    "jryj": "params=dDJ2WUY3aGJIZGZYQXV6L0YwK2ZwN01MTU40Z0V3dGZEUlUyK2doYnREUk91c0w5UVN0YVpqNXB2VmtqNFdwaQ",
}


def valid(path: Path) -> bool:
    """已有文件是否为有效抓取（摘要不是查询页外壳）。"""
    try:
        items = json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return False
    good = sum(1 for it in items
               if len(it.get("abstract", "")) > 60 and "ISSN 基金资助" not in it.get("abstract", ""))
    return bool(items) and good / len(items) >= 0.6


def extract(text: str) -> tuple[str, str]:
    flat = re.sub(r"[\s ]+", " ", text)
    m = re.search(r"摘\s*要\s*[:：]?\s*(.{40,1500}?)(?=关\s*键\s*词|Abstract|参考文献|英文摘要)", flat)
    if not m:
        start = flat.find("摘")
        chunk = flat[start:start + 1200] if start >= 0 else ""
        cut = re.search(r"关\s*键\s*词|Abstract|参考文献", chunk[10:])
        if cut:
            chunk = chunk[: cut.start() + 10]
        abstract = chunk if len(chunk) > 80 else ""
    else:
        abstract = m.group(1)
    abstract = re.sub(r"^摘\s*要\s*[:：]?\s*", "", abstract)
    k = re.search(r"关\s*键\s*词\s*[:：]?\s*(.{2,120}?)(?:Abstract|参考文献|作者|基金|英文)", flat)
    keywords = k.group(1).strip() if k else ""
    abstract = abstract.strip()
    if "ISSN 基金资助" in abstract or "出 版 物" in abstract:
        abstract = ""
    return abstract, keywords


def main() -> None:
    port = int(sys.argv[1])
    codes = sys.argv[2:]
    OUT.mkdir(parents=True, exist_ok=True)
    profile = Path(tempfile.mkdtemp(prefix=f"abs3-{port}-"))
    proc = subprocess.Popen(
        [CHROME, f"--remote-debugging-port={port}", f"--user-data-dir={profile}",
         "--no-first-run", "--no-default-browser-check", "--ignore-certificate-errors"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
    )
    time.sleep(6)
    try:
        with sync_playwright() as p:
            browser = p.chromium.connect_over_cdp(f"http://127.0.0.1:{port}")
            page = browser.contexts[0].pages[0]
            for code in codes:
                spec = JOURNALS[code]
                url = ("https://www.ncpssd.org/journal/secure/details?" + spec
                       if spec.startswith("params=")
                       else f"https://www.ncpssd.org/journal/details?{spec}&nav=1&langType=1")
                page.goto(url, wait_until="domcontentloaded", timeout=60000)
                page.wait_for_timeout(2500)
                for year in YEARS:
                    try:
                        page.locator(".year .title", has_text=f"{year}年").first.click()
                        page.wait_for_timeout(1800)
                    except Exception:  # noqa: BLE001
                        continue
                    issues = page.evaluate(
                        """(y) => {
                          const blk = [...document.querySelectorAll('.year')]
                            .find(z => ((z.querySelector('.title')||{}).innerText||'').includes(y));
                          if (!blk) return [];
                          return [...blk.querySelectorAll('a')]
                            .map(a => ({n:a.innerText.trim(), h:a.getAttribute('href')}))
                            .filter(x => x.h && /^\\d+$/.test(x.n));
                        }""",
                        year,
                    )
                    for link in issues:
                        target = OUT / f"{code}_{year}_{int(link['n']):02d}.json"
                        if target.exists() and valid(target):
                            continue
                        issue_url = link["h"] if link["h"].startswith("http") else "https://www.ncpssd.org" + link["h"]
                        page.goto(issue_url, wait_until="domcontentloaded", timeout=60000)
                        page.wait_for_timeout(1200)
                        rows = page.evaluate(
                            """() => [...document.querySelectorAll('p.bg-r')].map(p => {
                                  const a = p.querySelector('a[onclick]');
                                  const t = (p.querySelector('a[title]') || {}).title || '';
                                  const m = a ? (a.getAttribute('onclick')||'').match(/openDetail\\('([^']+)'\\)/) : null;
                                  return {title: (t||'').trim(), url: m ? m[1] : ''};
                                }).filter(x => x.title && x.url)"""
                        )
                        items = []
                        for row in rows:
                            detail = row["url"]
                            detail = detail if detail.startswith("http") else "https://www.ncpssd.org" + detail
                            try:
                                abstract, keywords = "", ""
                                for attempt in range(2):
                                    try:
                                        page.goto(detail, wait_until="domcontentloaded", timeout=45000)
                                        page.wait_for_timeout(1200 if attempt == 0 else 2200)
                                        abstract, keywords = extract(page.inner_text("body"))
                                    except Exception:  # noqa: BLE001
                                        abstract, keywords = "", ""
                                    if abstract:
                                        break
                            except Exception:  # noqa: BLE001
                                abstract, keywords = "", ""
                            items.append({"title": row["title"], "abstract": abstract, "keywords": keywords})
                            time.sleep(0.15)
                        target.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")
                        got = sum(1 for i in items if i["abstract"])
                        print(f"{code} {year}-{int(link['n']):02d}: {got}/{len(items)}", flush=True)
            browser.close()
    finally:
        proc.terminate()


if __name__ == "__main__":
    main()
