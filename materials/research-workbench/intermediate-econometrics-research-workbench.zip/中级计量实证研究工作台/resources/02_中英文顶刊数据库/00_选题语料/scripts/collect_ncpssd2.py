"""NCPSSD 抓取器：按 gch/params 抓 2024—2026 各期目录（标题/作者/页码）。

用法：
    python3 collect_ncpssd2.py jjyj 95645X
    python3 collect_ncpssd2.py glsj "params=V2ZQ..."
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

PORT = 9338
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "raw" / "ncpssd"
YEARS = ["2024", "2025", "2026"]

PAGE_RE = re.compile(r"^\(([0-9A-Za-z\-–]+)\)$")


def journal_url(spec: str) -> str:
    if spec.startswith("params="):
        return "https://www.ncpssd.org/journal/secure/details?" + spec
    return f"https://www.ncpssd.org/journal/details?gch={spec}&nav=1&langType=1"


def parse_articles(lines: list[str]) -> list[dict]:
    items: list[dict] = []
    buf: list[str] = []
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        m = PAGE_RE.match(line)
        if m and buf:
            title = buf[0]
            authors = buf[1] if len(buf) > 1 else ""
            items.append({"title": title, "authors": authors, "pages": m.group(1)})
            buf = []
        else:
            buf.append(line)
    return items


def main() -> None:
    code, spec = sys.argv[1], sys.argv[2]
    RAW.mkdir(parents=True, exist_ok=True)
    profile = Path(tempfile.mkdtemp(prefix="ncp2-"))
    proc = subprocess.Popen(
        [CHROME, f"--remote-debugging-port={PORT}", f"--user-data-dir={profile}",
         "--no-first-run", "--no-default-browser-check", "--ignore-certificate-errors"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
    )
    time.sleep(6)
    try:
        with sync_playwright() as p:
            browser = p.chromium.connect_over_cdp(f"http://127.0.0.1:{PORT}")
            page = browser.contexts[0].pages[0]
            page.goto(journal_url(spec), wait_until="domcontentloaded", timeout=60000)
            page.wait_for_timeout(3500)
            for year in YEARS:
                try:
                    page.locator(".year .title", has_text=f"{year}年").first.click()
                    page.wait_for_timeout(2500)
                except Exception:  # noqa: BLE001
                    print(f"{code} {year}: 年份未找到")
                    continue
                links = page.evaluate(
                    """(y) => {
                      const blk = [...document.querySelectorAll('.year')]
                        .find(z => ((z.querySelector('.title')||{}).innerText||'').includes(y));
                      if (!blk) return [];
                      return [...blk.querySelectorAll('a')]
                        .map(a => ({n:a.innerText.trim(), h:a.getAttribute('href')}))
                        .filter(x => x.h && /^\\d+$/.test(x.n));
                    }""",
                    year,
                )
                print(f"{code} {year}: {len(links)} 期")
                for link in links:
                    url = link["h"] if link["h"].startswith("http") else "https://www.ncpssd.org" + link["h"]
                    page.goto(url, wait_until="domcontentloaded", timeout=60000)
                    page.wait_for_timeout(2500)
                    lines = page.evaluate(
                        """() => {
                          const t = document.body.innerText;
                          const i = t.indexOf('期');
                          return t.split('\\n').map(s => s.trim()).filter(Boolean);
                        }"""
                    )
                    # 从「第N期」之后开始解析
                    start = next((k for k, s in enumerate(lines) if s.startswith(year + "年 第")), 0)
                    items = parse_articles(lines[start + 1:])
                    items = [i for i in items if len(i["title"]) > 4]
                    if items:
                        out = RAW / f"{code}_{year}_{int(link['n']):02d}.json"
                        out.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")
                        print(f"  {year}-{int(link['n']):02d}: {len(items)} 篇")
                    time.sleep(0.3)
            browser.close()
    finally:
        proc.terminate()


if __name__ == "__main__":
    main()
