"""把中英文题录分成「理论分析 / 计量实证 / 理论+实证」。

中文：有摘要时优先结合摘要+题目判读，无摘要时按题目判读，并在 type_basis 字段标明依据。
英文：按摘要 + 题目判读，并剔除年报、审稿人名单、审计报告、勘误等非研究论文条目。
"""
from __future__ import annotations

import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"

ZH_THEORY_T = ("理论", "模型", "框架", "均衡", "博弈", "机制设计", "述评", "研究综述",
               "逻辑", "范式", "命题", "何以可能")
ZH_EMP_T = ("检验", "证据", "数据", "实证", "案例", "测度", "测算", "估计", "评估",
            "影响", "效应", "作用", "回归", "调查", "实验", "经验")

ABS_THEORY = ("构建", "建立一个", "理论模型", "一般均衡", "命题", "推导", "证明",
              "模型刻画", "理论分析")
ABS_EMP = ("实证", "数据", "样本", "回归", "估计", "检验", "检验结果", "识别",
           "面板", "调查", "实验", "本文发现", "结果表明", "稳健")

EN_THEORY = ("we develop a model", "we present a model", "we build a model", "model of",
             "theoretical", "proposition", "we characterize", "equilibrium model",
             "we provide a theory", "theory of", "we study a model", "we set up a model")
EN_EMPIRICAL = ("data", "estimate", "estimat", "regression", "empirical", "experiment",
                "identification", "panel", "we find", "sample", "survey", "evidence",
                "we study", "we examine", "we show", "we document", "we exploit", "using")

EN_NOISE = (
    "annual report", "recent referees", "econometrica referees", "report of independent auditor",
    "election of fellows", "fellows of the econometric society", "submission of manuscripts",
    "issue information", "front matter", "back matter", "erratum", "corrigendum",
    "in memoriam", "obituary",
)


def classify_zh(title: str, abstract: str) -> tuple[str, str]:
    if abstract and len(abstract.strip()) >= 20:
        th = any(w in abstract for w in ABS_THEORY) or any(w in title for w in ZH_THEORY_T)
        em = any(w in abstract for w in ABS_EMP) or any(w in title for w in ZH_EMP_T)
        basis = "摘要+题目"
    else:
        th = any(w in title for w in ZH_THEORY_T)
        em = any(w in title for w in ZH_EMP_T)
        basis = "仅题目"
    if th and em:
        return "理论+实证", basis
    if th:
        return "理论分析", basis
    return "计量实证", basis


def classify_en(title: str, abstract: str) -> tuple[str, str]:
    text = (title + " " + abstract).lower() if abstract else title.lower()
    basis = "摘要+题目" if abstract else "仅题目"
    theory = any(w in text for w in EN_THEORY)
    empirical = any(w in text for w in EN_EMPIRICAL)
    if theory and empirical:
        return "理论+实证", basis
    if theory:
        return "理论分析", basis
    return "计量实证", basis


def norm_en_key(title: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", title.lower())


def is_en_noise(title: str) -> bool:
    tl = title.lower().strip()
    return len(tl) < 8 or any(w in tl for w in EN_NOISE)


def main() -> None:
    # 中文
    zh_rows = list(csv.DictReader((DATA / "titles_coded.csv").open(encoding="utf-8-sig")))
    zh_counter = Counter()
    by_journal = defaultdict(Counter)
    by_year = defaultdict(Counter)
    for row in zh_rows:
        ptype, basis = classify_zh(row["title"], row.get("abstract", ""))
        row["paper_type"] = ptype
        row["type_basis"] = basis
        zh_counter[ptype] += 1
        by_journal[row["journal_name"]][ptype] += 1
        by_year[row["year"]][ptype] += 1

    fields = list(zh_rows[0].keys())
    with (DATA / "titles_coded.csv").open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(zh_rows)

    # 英文（优先从 raw/en_top5 读取并清洗，若 raw 不存在则直接清洗现有 en_titles_coded.csv）
    en_raw_dir = ROOT / "raw" / "en_top5"
    en_dedup: dict[tuple, dict] = {}
    dropped_en = 0
    if en_raw_dir.exists():
        raw_iter = []
        for path in sorted(en_raw_dir.glob("*.json")):
            code = path.stem
            for item in json.loads(path.read_text(encoding="utf-8")):
                raw_iter.append((code, str(item["year"]), item["title"], item.get("doi", ""), item.get("abstract", "")))
    else:
        raw_iter = [
            (r["journal"], r["year"], r["title"], r.get("doi", ""), r.get("abstract", ""))
            for r in csv.DictReader((DATA / "en_titles_coded.csv").open(encoding="utf-8-sig"))
        ]

    for code, year, title, doi, abstract in raw_iter:
        title = re.sub(r"\s+", " ", title).strip()
        abstract = re.sub(r"\s+", " ", (abstract or "")).strip()
        if is_en_noise(title):
            dropped_en += 1
            continue
        k = (code, year, norm_en_key(title))
        cur = en_dedup.get(k)
        if cur is not None:
            if not cur["abstract"] and abstract:
                cur["abstract"] = abstract
            if not cur["doi"] and doi:
                cur["doi"] = doi
            continue
        en_dedup[k] = {"journal": code, "year": year, "title": title, "doi": doi, "abstract": abstract}

    en_rows: list[dict] = []
    for item in en_dedup.values():
        ptype, basis = classify_en(item["title"], item["abstract"])
        item["paper_type"] = ptype
        item["type_basis"] = basis
        en_rows.append(item)

    en_rows.sort(key=lambda r: (r["journal"], r["year"], r["title"]))
    with (DATA / "en_titles_coded.csv").open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["journal", "year", "title", "doi", "abstract", "paper_type", "type_basis"])
        writer.writeheader()
        writer.writerows(en_rows)

    en_counter = Counter(r["paper_type"] for r in en_rows)
    print(f"中文七刊 {len(zh_rows)} 篇（摘要+题目判读 {sum(1 for r in zh_rows if r['type_basis']=='摘要+题目')} 篇）：", zh_counter.most_common())
    print(f"英文五刊 {len(en_rows)} 篇（剔除 {dropped_en} 条非研究条目，含摘要 {sum(1 for r in en_rows if r['abstract'])} 篇）：", en_counter.most_common())
    print("\n中文各刊：")
    for j, c in by_journal.items():
        n = sum(c.values())
        print(f"  {j} (n={n}): " + "，".join(f"{k} {v / n * 100:.1f}%" for k, v in c.most_common()))


if __name__ == "__main__":
    main()
