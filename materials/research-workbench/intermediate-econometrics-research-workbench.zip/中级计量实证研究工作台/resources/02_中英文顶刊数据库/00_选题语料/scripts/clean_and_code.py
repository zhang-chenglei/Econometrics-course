"""清洗题录并做初步编码，输出 data/titles_coded.csv。"""
from __future__ import annotations

import csv
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "data" / "titles_all.csv"
OUT = ROOT / "data" / "titles_coded.csv"

CAUSAL = ("影响", "效应", "作用", "促进", "抑制", "冲击", "因果", "机制", "是否",
          "提高", "降低", "带动", "挤出", "溢出", "回报", "惩罚", "激励", "赋能",
          "能否", "如何", "何以", "为何", "为什么", "证据", "来自", "视角",
          "考察", "检验", "发现")
MEASURE = ("测度", "度量", "衡量", "测算", "指数", "编制", "估算", "构造")
PREDICT = ("预测", "预警", "预报")
THEORY = ("理论", "模型", "框架", "一般均衡", "博弈", "机制设计")
METHOD = ("综述", "述评", "评述", "文献综述", "研究进展", "前沿进展")
CASE = ("案例研究", "案例分析")
RELATION = ("与", "、", "和")

POLICY_WORDS = (
    "改革", "政策", "试点", "规划", "战略", "制度", "监管", "补贴", "税收",
    "五年规划", "十四五", "十五五", "试验区", "自贸区", "一带一路", "乡村振兴",
    "共同富裕", "新质生产力", "碳中和", "碳达峰", "数字经济", "人工智能",
)


def classify(title: str) -> str:
    """粗分题目类型；顺序即优先级。"""
    hit = lambda words: any(w in title for w in words)  # noqa: E731
    if hit(METHOD):
        return "方法/综述"
    if hit(THEORY):
        return "理论/模型"
    if hit(PREDICT):
        return "预测"
    if hit(MEASURE):
        return "测量/构造"
    if hit(CASE):
        return "案例研究"
    if hit(CAUSAL):
        return "因果/效应"
    if hit(RELATION):
        return "关系/机制"
    return "其他"


def features(title: str) -> dict[str, int]:
    return {
        "has_dash_subtitle": int(any(mark in title for mark in ("——", "--", "：", ":"))),
        "is_question": int(title.rstrip().endswith(("？", "?"))),
        "has_policy_word": int(any(w in title for w in POLICY_WORDS)),
        "has_number": int(bool(re.search(r"\d", title))),
        "len": len(title),
    }


def main() -> None:
    rows = list(csv.DictReader(SRC.open(encoding="utf-8-sig")))
    coded: list[dict] = []
    for row in rows:
        title = re.sub(r"\s+", " ", row["title"]).strip()
        row["title"] = title
        row.update({k: str(v) for k, v in features(title).items()})
        row["qtype"] = classify(title)
        coded.append(row)

    fieldnames = list(rows[0].keys()) + ["qtype", "has_dash_subtitle", "is_question",
                                         "has_policy_word", "has_number", "len"]
    # Ensure no duplicate column names if re-run
    seen: list[str] = []
    for f in fieldnames:
        if f not in seen:
            seen.append(f)
    with OUT.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=seen)
        writer.writeheader()
        writer.writerows(coded)

    print(f"编码完成：{len(coded)} 条 -> {OUT}")
    print("\n类型分布：", Counter(r["qtype"] for r in coded).most_common())


if __name__ == "__main__":
    main()
