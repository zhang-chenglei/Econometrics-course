"""从《世界经济》官网（magtech）抓 2024—2026 各期目录。"""
from __future__ import annotations

import json
import re
import subprocess
import tempfile
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

PORT = 9339
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
RAW = Path(__file__).resolve().parent.parent / "raw" / "sjjj_web"
YEARS = {"2024": 47, "2025": 48, "2026": 49}


def main() -> None:
    RAW.mkdir(parents=True, exist_ok=True)
    profile = Path(tempfile.mkdtemp(prefix="mt-"))
    proc = subprocess.Popen(
        [CHROME, f"--remote-debugging-port={PORT}", f"--user-data-dir={profile}",
         "--no-first-run", "--no-default-browser-check", "--ignore-certificate-errors"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
    )
    time.sleep(6)
    try:
        with sync_playwright() as p:
            browser = p.chromium.connect_over_cdp(f"http://127.0.0.1:{PORT}")
            page = browser.contexts[0].pages[0]
            for year, vol in YEARS.items():
                for issue in range(1, 13):
                    url = f"https://sjjj.magtech.com.cn/CN/Y{year}/V{vol}/I{issue}"
                    page.goto(url, wait_until="domcontentloaded", timeout=45000)
                    page.wait_for_timeout(1500)
                    rows = page.evaluate(
                        """() => [...document.querySelectorAll('a')]
                             .map(a => ({t:(a.innerText||'').trim(), h:a.getAttribute('href')||''}))
                             .filter(x => /\\/CN\\/Y\\d{4}\\/V\\d+\\/I\\d+\\/\\d+$/.test(x.h) && x.t.length > 6)"""
                    )
                    if not rows:
                        print(f"{year}-{issue:02d}: 空")
                        continue
                    items = []
                    seen = set()
                    for r in rows:
                        if r["t"] in seen:
                            continue
                        seen.add(r["t"])
                        items.append({"title": r["t"], "url": r["h"]})
                    out = RAW / f"sjjj_{year}_{issue:02d}.json"
                    out.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")
                    print(f"{year}-{issue:02d}: {len(items)} 篇")
                    time.sleep(0.3)
            browser.close()
    finally:
        proc.terminate()


if __name__ == "__main__":
    main()
