"""生成 2024-2026 年中英文顶刊高频主题词对比图（fig6_top_topics.png）。"""
from __future__ import annotations

import csv
import re
from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.font_manager as fm
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent
FIG = ROOT / "figures"
FIG.mkdir(parents=True, exist_ok=True)


def pick_font() -> str:
    available = {f.name for f in fm.fontManager.ttflist}
    for name in ("Songti SC", "STSong", "Heiti SC", "PingFang SC", "Arial Unicode MS"):
        if name in available:
            return name
    raise SystemExit("no cjk font")


def main() -> None:
    plt.rcParams["font.family"] = pick_font()

    cn_kw = Counter()
    with (ROOT / "data" / "titles_coded.csv").open(encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            kws = [k.strip() for k in re.split(r"[;；,，、]", r.get("keywords", "")) if k.strip()]
            for k in kws:
                if len(k) >= 2:
                    cn_kw[k] += 1
    cn_top = cn_kw.most_common(15)[::-1]

    en_stop = set(
        "the of and in from to for on a an with by as at is are evidence effect effects "
        "empirical theory model models analysis dynamic dynamics optimal economic economy "
        "economics market markets policy policies growth price prices data new how do why "
        "what when under between equilibrium welfare value values role impact impacts rate "
        "rates level levels long run short experimental experiment implications versus "
        "comment robust inference firm change".split()
    )
    en_uni = Counter()
    with (ROOT / "data" / "en_titles_coded.csv").open(encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            words = re.findall(r"[a-z]{3,}", r.get("title", "").lower())
            seen = set()
            for w in words:
                if w not in en_stop and w not in seen:
                    en_uni[w] += 1
                    seen.add(w)
    en_top = en_uni.most_common(15)[::-1]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.6, 5.2), dpi=220)

    # Left: CN keywords
    c_labels = [k for k, _ in cn_top]
    c_vals = [v for _, v in cn_top]
    bars1 = ax1.barh(c_labels, c_vals, color="#164e63", height=0.66)
    ax1.set_title("中文七刊高频作者关键词 Top 15\n（基于 1,023 篇含关键词题录）", fontsize=11, pad=10)
    ax1.set_xlabel("出现篇数", fontsize=9.5)
    ax1.set_xlim(0, max(c_vals) * 1.18)
    for b, v in zip(bars1, c_vals):
        ax1.text(v + 0.5, b.get_y() + b.get_height() / 2, str(v), va="center", fontsize=8.5, color="#1e293b")
    ax1.spines["top"].set_visible(False)
    ax1.spines["right"].set_visible(False)
    ax1.tick_params(axis="both", labelsize=9)

    # Right: EN title concepts
    e_labels = [k for k, _ in en_top]
    e_vals = [v for _, v in en_top]
    bars2 = ax2.barh(e_labels, e_vals, color="#941f3a", height=0.66)
    ax2.set_title("英文五刊题目高频核心议题词 Top 15\n（基于 1,097 篇题目，已过滤方法与虚词）", fontsize=11, pad=10)
    ax2.set_xlabel("出现篇数", fontsize=9.5)
    ax2.set_xlim(0, max(e_vals) * 1.18)
    for b, v in zip(bars2, e_vals):
        ax2.text(v + 0.7, b.get_y() + b.get_height() / 2, str(v), va="center", fontsize=8.5, color="#1e293b")
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)
    ax2.tick_params(axis="both", labelsize=9)

    fig.tight_layout(w_pad=2.8)
    out_path = FIG / "fig6_top_topics.png"
    fig.savefig(out_path, bbox_inches="tight", dpi=220)
    plt.close(fig)
    print(f"Saved {out_path}")


if __name__ == "__main__":
    main()
