"""从 NAPSTIC（国家学术搜索）抓取六本中文顶刊 2024—2026 的题录。

用法：
    python3 collect_napstic.py                 # 全部六刊
    python3 collect_napstic.py jjyj jjx        # 指定刊
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

PORT = 9334
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "raw" / "napstic"
LOG = ROOT / "reports" / "collect_log.txt"

JOURNALS = {
    "jjyj": "经济研究",
    "glsj": "管理世界",
    "jjx": "经济学（季刊）",
    "zggyjj": "中国工业经济",
    "sljjjsjjyj": "数量经济技术经济研究",
    "sjjj": "世界经济",
    "jryj": "金融研究",
}
YEARS = ["2024", "2025", "2026"]

EXTRACT = """() => [...document.querySelectorAll('.article_item')].map(el => ({
  title: (el.querySelector('h4 a') || {}).title || (el.querySelector('h4') || {}).innerText || '',
  authors: [...el.querySelectorAll('.creators span')].map(s => s.getAttribute('title') || s.innerText).join(','),
  pages: (el.querySelector('.submissionPage') || {}).innerText || '',
  abstract: (el.querySelector('.abstract .ignore') || {}).innerText || '',
  keywords: [...el.querySelectorAll('.keywords span')].map(s => s.innerText).join(';'),
  url: (el.querySelector('h4 a') || {}).href || ''
}))"""


def log(msg: str) -> None:
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as fh:
        fh.write(msg + "\n")
    print(msg, flush=True)


def url_for(code: str, year: str, issue: int, page: int) -> str:
    return (
        f"https://search.napstic.cn/literature/oaj/{code}"
        f"?page={page}&activeYear={year}&activeIssue={issue}"
    )


def collect_journal(page, code: str, name: str) -> None:
    for year in YEARS:
        empty_streak = 0
        for issue in range(1, 13):
            items: list[dict] = []
            for pageno in range(1, 8):
                page.goto(url_for(code, year, issue, pageno), wait_until="domcontentloaded", timeout=40000)
                page.wait_for_timeout(1200)
                chunk = page.evaluate(EXTRACT)
                if not chunk:
                    break
                items.extend(chunk)
                if len(chunk) < 10:
                    break
                time.sleep(0.4)
            if items:
                empty_streak = 0
                out = RAW / f"{code}_{year}_{issue:02d}.json"
                out.write_text(json.dumps(items, ensure_ascii=False, indent=1), encoding="utf-8")
                log(f"{name} {year}-{issue:02d}: {len(items)} 条")
            else:
                empty_streak += 1
                if issue == 1:
                    log(f"{name} {year}: 无数据，跳过该年")
                    break
                if empty_streak >= 2:
                    break


def main() -> None:
    codes = sys.argv[1:] or list(JOURNALS)
    RAW.mkdir(parents=True, exist_ok=True)
    profile = Path(tempfile.mkdtemp(prefix="napstic-"))
    proc = subprocess.Popen(
        [CHROME, f"--remote-debugging-port={PORT}", f"--user-data-dir={profile}",
         "--no-first-run", "--no-default-browser-check"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True,
    )
    time.sleep(6)
    try:
        with sync_playwright() as p:
            browser = p.chromium.connect_over_cdp(f"http://127.0.0.1:{PORT}")
            page = browser.contexts[0].pages[0]
            for code in codes:
                log(f"=== 开始 {JOURNALS.get(code, code)} ({code})")
                collect_journal(page, code, JOURNALS.get(code, code))
            browser.close()
    finally:
        proc.terminate()


if __name__ == "__main__":
    main()
