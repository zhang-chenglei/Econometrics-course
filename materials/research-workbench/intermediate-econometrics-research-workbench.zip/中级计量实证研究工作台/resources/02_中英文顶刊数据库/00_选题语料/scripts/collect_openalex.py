"""抓取英文 Top5（AER/QJE/JPE/Econometrica/ReStud）2024—2026 的题录与摘要。"""
from __future__ import annotations

import json
import subprocess
import time
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "raw" / "en_top5"

JOURNALS = {
    "AER": ("0002-8282", "American Economic Review"),
    "QJE": ("0033-5533", "Quarterly Journal of Economics"),
    "JPE": ("0022-3808", "Journal of Political Economy"),
    "ECMA": ("0012-9682", "Econometrica"),
    "RESTUD": ("0034-6527", "Review of Economic Studies"),
}
BASE = "https://api.openalex.org/works"


def fetch(issn: str) -> list[dict]:
    out: list[dict] = []
    page = 1
    while True:
        params = {
            "filter": f"primary_location.source.issn:{issn},publication_year:2024-2026,type:article",
            "per-page": "200",
            "page": str(page),
            "select": "title,publication_year,doi,abstract_inverted_index",
            "mailto": "teacher@example.com",
        }
        url = BASE + "?" + urllib.parse.urlencode(params)
        raw = subprocess.run(
            ["curl", "-s", "--max-time", "60", url],
            capture_output=True, text=True, check=True,
        ).stdout
        data = json.loads(raw)
        results = data.get("results", [])
        out.extend(results)
        total = data.get("meta", {}).get("count", 0)
        if len(results) < 200 or len(out) >= total:
            break
        page += 1
        time.sleep(0.3)
    return out


def abstract_text(inv: dict | None) -> str:
    if not inv:
        return ""
    pos: dict[int, str] = {}
    for word, idxs in inv.items():
        for i in idxs:
            pos[i] = word
    return " ".join(pos[i] for i in sorted(pos))


def main() -> None:
    RAW.mkdir(parents=True, exist_ok=True)
    for code, (issn, name) in JOURNALS.items():
        rows = fetch(issn)
        clean = [
            {
                "title": (r.get("title") or "").strip(),
                "year": r.get("publication_year"),
                "doi": r.get("doi"),
                "abstract": abstract_text(r.get("abstract_inverted_index")),
            }
            for r in rows
            if r.get("title")
        ]
        out = RAW / f"{code}.json"
        out.write_text(json.dumps(clean, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"{code} {name}: {len(clean)} 篇")


if __name__ == "__main__":
    main()
