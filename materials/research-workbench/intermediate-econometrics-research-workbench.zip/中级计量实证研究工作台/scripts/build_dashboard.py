"""Rebuild the offline research dashboard from Markdown, CSV, task cards, and project files."""
import csv
import os
import re
import sys
import tempfile
from datetime import datetime
from html import escape
from pathlib import Path
from urllib.parse import quote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
RESEARCH = ROOT / "research"
RESOURCES = ROOT / "resources"
TASKS_DIR = ROOT / "tasks"

SHELL = """<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>经济学实证研究工作台 · Economics Research Lab</title><style>
:root{
  --bg:#ffffff;
  --surface:#ffffff;
  --surface-muted:#f8fafc;
  --surface-subtle:#f1f5f9;
  --ink:#0f172a;
  --muted:#475569;
  --border:#e2e8f0;
  --primary:#c8102e;
  --primary-hover:#a80d27;
  --primary-soft:rgba(200,16,46,.08);
  --primary-wash:rgba(200,16,46,.04);
  --primary-ring:rgba(200,16,46,.20);
  --primary-glow:rgba(200,16,46,.10);
  --slate-btn:#0f172a;
}
*{box-sizing:border-box}
::selection{background:var(--primary);color:#f8fafc}
body{margin:0;background:var(--bg);color:var(--ink);font:15.5px/1.72 "Inter",-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei","Source Han Sans SC",sans-serif;-webkit-font-smoothing:antialiased}
a{color:var(--primary);text-decoration:none;text-underline-offset:.24em}
a:hover{color:var(--primary-hover);text-decoration:underline}
a:focus-visible,button:focus-visible,input:focus-visible,summary:focus-visible{outline:2px solid var(--primary);outline-offset:2px}
header{position:sticky;top:0;z-index:20;background:rgba(255,255,255,.97);border-bottom:1px solid var(--border);padding:14px max(4vw,24px);display:flex;align-items:center;justify-content:space-between;gap:12px}
header a{color:var(--ink);text-decoration:none;display:flex;align-items:center;gap:11px;font-size:17px;letter-spacing:-.01em}
header a:hover{color:var(--ink);text-decoration:none}
.brand-mark{width:28px;height:28px;border-radius:7px;background:var(--primary);color:#fff;font-size:13px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;letter-spacing:.02em;flex-shrink:0}
header small{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.14em;color:var(--muted);font-size:11.5px;font-weight:600}
.layout{max-width:1360px;margin:auto;padding:30px 3.5vw 48px;display:grid;grid-template-columns:224px minmax(0,1fr);gap:34px}
aside{align-self:start;position:sticky;top:76px;background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:16px 12px}
aside h2{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--muted);margin:16px 0 6px;padding:0 10px;font-weight:600}
aside h2:first-of-type{margin-top:4px}
nav a{display:flex;align-items:center;justify-content:space-between;text-decoration:none;padding:7px 11px;border-radius:8px;color:var(--ink);font-size:14px;font-weight:500;margin-bottom:2px;transition:background .15s,color .15s}
nav a:hover{background:var(--surface-subtle);color:var(--primary);text-decoration:none}
nav a[aria-current=page]{background:var(--primary-soft);color:var(--primary);font-weight:650}
.nav-count{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px;padding:1px 7px;border-radius:999px;background:var(--surface-subtle);color:var(--muted)}
nav a[aria-current=page] .nav-count{background:var(--primary);color:#fff}
h1,h2,h3,p{margin:0}
h1{font-size:clamp(26px,3vw,34px);line-height:1.22;margin-bottom:14px;color:var(--ink);letter-spacing:-.02em;font-weight:750}
main h2{font-size:18px;margin:30px 0 12px;color:var(--ink);letter-spacing:-.01em;font-weight:700;display:flex;align-items:center;gap:10px}
main h2::before{content:"";width:18px;height:2px;border-radius:999px;background:rgba(200,16,46,.45);display:inline-block;flex-shrink:0}
h3{font-size:15.5px;margin-bottom:8px;color:var(--ink);font-weight:650}
main{min-width:0;overflow-wrap:anywhere}
section[id],h2[id]{scroll-margin-top:76px}
.hero{background:linear-gradient(180deg,var(--primary-wash) 0%,var(--surface-muted) 100%);border:1px solid var(--border);border-top:3px solid var(--primary);padding:26px 28px;border-radius:16px}
.hero-kicker{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;letter-spacing:.14em;color:var(--primary);font-weight:700;text-transform:uppercase}
.hero strong{display:block;font-size:clamp(22px,2.5vw,28px);line-height:1.38;margin:10px 0 10px;white-space:pre-line;font-weight:750;color:var(--ink)}
.hero-meta{color:var(--muted);font-size:14.5px;margin-bottom:16px}
.btn-row{display:flex;flex-wrap:wrap;gap:10px;margin-top:12px;align-items:center}
.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:9px;border:1px solid var(--border);background:var(--surface);color:var(--ink);font:inherit;font-size:14px;font-weight:600;cursor:pointer;text-decoration:none;transition:all .15s}
.btn:hover{border-color:var(--primary-ring);color:var(--primary);text-decoration:none}
.btn-primary{background:var(--primary);border-color:var(--primary);color:#fff}
.btn-primary:hover{background:var(--primary-hover);border-color:var(--primary-hover);color:#fff}
.btn-slate{background:var(--slate-btn);border-color:var(--slate-btn);color:#f8fafc}
.btn-slate:hover{background:#1e293b;border-color:#1e293b;color:#fff}
.onboard{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:22px 24px;margin-bottom:20px;box-shadow:0 2px 12px rgba(15,23,42,.03)}
.onboard-head{display:flex;flex-wrap:wrap;justify-content:space-between;align-items:center;gap:10px;margin-bottom:14px}
.pill{display:inline-block;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:650;background:var(--primary-soft);color:var(--primary)}
.pill-muted{background:var(--surface-subtle);color:var(--muted)}
.quick-steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px;margin:12px 0 14px}
.qstep{background:var(--surface-muted);border:1px solid var(--border);border-radius:12px;padding:14px 16px}
.qstep > b{display:block;color:var(--ink);margin-bottom:4px;font-size:14.5px}
.qstep span.step-num{color:var(--primary);font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px;font-weight:700;letter-spacing:.08em;display:block;margin-bottom:3px}
.qstep p{font-size:13.5px;color:var(--muted);line-height:1.6}
.prompt-box{background:var(--surface-muted);border:1px solid var(--border);border-radius:11px;padding:12px 14px;font-size:13.5px;line-height:1.65;margin-top:8px;display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between}
.prompt-box code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;color:var(--ink);white-space:pre-wrap;flex:1;min-width:220px;background:transparent;padding:0}
.grid,.resources{display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(min(220px,100%),1fr))}
.box,.resources a,.stage{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:18px 20px;transition:border-color .15s,box-shadow .15s,transform .15s}
.resources a,.stage{text-decoration:none;color:var(--ink)}
.resources small,.stage small{display:block;color:var(--muted);margin-top:3px;font-size:12.5px}
.flow{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}
.stage{padding:16px 18px}
.stage small{color:var(--primary);font-weight:650;font-size:12px;margin-bottom:4px}
.stage span.stage-ch{display:block;font-size:12.5px;color:var(--muted);margin-top:4px}
.resources a:hover,.stage:hover{border-color:var(--primary-ring);box-shadow:0 8px 24px var(--primary-glow);transform:translateY(-1px);text-decoration:none}
.empty{padding:14px 18px;border-left:3px solid rgba(200,16,46,.35);background:var(--surface-muted);border-radius:0 10px 10px 0;color:var(--muted)}
.files{margin:8px 0 0;padding:0;list-style:none}
.files li{border-bottom:1px solid var(--surface-subtle);padding:9px 0}
.files li:last-child{border-bottom:none}
.files img{display:block;max-width:min(100%,650px);max-height:340px;object-fit:contain;margin-top:10px;border-radius:10px;border:1px solid var(--border)}
.scroll{overflow:auto;margin-top:12px;background:white;max-height:70vh;border-radius:10px;border:1px solid var(--border)}
input{padding:8px 12px;border:1px solid var(--border);border-radius:8px;font:inherit;max-width:100%;background:var(--surface);color:var(--ink)}
summary{cursor:pointer;color:var(--ink);font-weight:650}
summary:hover{color:var(--primary)}
details{margin-top:12px}
.lines{line-height:1.75;color:var(--ink)}
.sub{color:var(--muted);margin-bottom:16px;font-size:14.5px}
@media(max-height:820px){aside{position:static}}
@media(max-width:900px){.layout{display:block;padding:18px}aside{position:static;margin-bottom:20px}nav{display:flex;gap:4px;flex-wrap:wrap}aside h2{margin-top:10px;padding:0 4px}nav a{padding:5px 10px;font-size:14px}header small{display:none}}
@EXTRA_CSS@
</style></head><body>
<header>
  <a href="#overview"><span class="brand-mark">经</span><b>经济学实证研究工作台</b></a>
  <small>ECONOMICS RESEARCH LAB</small>
</header>
<div class="layout">
  <aside>
    <h2>总览与课堂</h2>
    <nav aria-label="总览与课堂">
      <a href="#overview">研究概况</a>
      <a href="#tasks">课堂任务卡 <span class="nav-count">@TASK_COUNT@</span></a>
      <a href="#guide">使用指南与示例</a>
    </nav>
    <h2>研究流程</h2>
    <nav aria-label="研究流程">
      <a href="#workshop">1. 选题与文献</a>
      <a href="#stage-data">2. 数据与变量</a>
      <a href="#stage-methods">3. 研究设计与模型</a>
      <a href="#stage-analysis">4. 实证分析与检验</a>
      <a href="#stage-paper">5. 论文与研究表达</a>
    </nav>
    <h2>我的研究档案</h2>
    <nav aria-label="研究资料">
      @MODULE_NAV@
    </nav>
  </aside>
  <main>"""

CSS = """
.lines,.field{white-space:pre-line}
.steps{display:flex;flex-wrap:wrap;gap:7px;margin:0 0 18px}
.steps a{padding:7px 13px;border:1px solid var(--border);border-radius:9px;background:var(--surface);text-decoration:none;color:var(--ink);font-size:13.5px;font-weight:600;transition:all .15s}
.steps a:hover{border-color:var(--primary-ring);color:var(--primary);text-decoration:none}
.steps a[aria-current=step]{background:var(--primary);border-color:var(--primary);color:#fff}
.panel{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:24px}
.panel h2{margin-top:0}.panel h3{margin:18px 0 6px;color:var(--ink)}.panel dl{margin:4px 0}
dt{font-weight:650;color:var(--muted);font-size:13px}dd{margin:2px 0 12px;white-space:pre-line;color:var(--ink)}
.refs{display:flex;flex-wrap:wrap;gap:8px 16px;margin-top:6px}
.papers details{border:1px solid var(--border);border-radius:12px;background:var(--surface);padding:13px 18px;margin-top:10px}
.action{margin:14px 0;padding:12px 16px;border-left:3px solid var(--primary);background:var(--primary-wash);border-radius:0 10px 10px 0;white-space:pre-line}
.action strong{display:block;color:var(--primary);margin-bottom:3px;font-size:13.5px}
.generated{margin-top:32px;color:var(--muted);font-size:13px;border-top:1px solid var(--border);padding-top:14px}
.paper-fields{display:grid;grid-template-columns:1.05fr 2fr 1.8fr 1.15fr 1fr;gap:12px}
.paper-fields .preview{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;overflow-wrap:anywhere}
.paper-fields small{display:block;color:var(--muted);font-size:12px;font-weight:500}.paper-fields span{min-width:0}
.papers dl{border-top:1px solid var(--border);padding-top:14px}
.timeline{border-left:2px solid var(--primary-ring);padding-left:20px}.version{padding:0 0 16px}
.shortcut-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-bottom:6px}
.shortcut-card{display:flex;flex-direction:column;justify-content:space-between;background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:18px 20px;text-decoration:none;color:var(--ink);transition:border-color .15s,box-shadow .15s,transform .15s}
.shortcut-card:hover{border-color:var(--primary-ring);box-shadow:0 8px 24px var(--primary-glow);transform:translateY(-2px);text-decoration:none}
.shortcut-card b{font-size:15.5px;margin:10px 0 4px;color:var(--ink)}
.shortcut-card span.desc{font-size:13.5px;color:var(--muted);line-height:1.55}
.shortcut-card span.cta{margin-top:12px;font-size:13.5px;font-weight:650;color:var(--primary)}
.md-view{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:24px 28px}
.md-view h2{margin:22px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--surface-subtle);font-size:18px}
.md-view h3{margin:16px 0 8px;color:var(--ink);font-size:15.5px}
.md-view p{margin:8px 0;color:var(--ink)}
.md-view ul,.md-view ol{margin:8px 0 12px;padding-left:22px;color:var(--ink)}
.md-view li{margin:4px 0}
.md-view blockquote{margin:10px 0;padding:10px 14px;border-left:3px solid var(--primary);background:var(--primary-wash);border-radius:0 8px 8px 0;color:var(--ink)}
.md-view code{background:var(--surface-subtle);padding:1px 6px;border-radius:5px;font-size:13px;color:var(--ink)}
.md-view pre{background:var(--slate-btn);color:#f8fafc;padding:12px 14px;border-radius:10px;overflow:auto}
.stage-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:22px 24px;margin-bottom:18px}
.note-box{background:var(--surface-muted);border-left:3px solid var(--primary);padding:12px 16px;border-radius:0 10px 10px 0;margin:12px 0;font-size:14.5px;color:var(--ink)}
.note-box ul{margin:6px 0 0;padding-left:20px}
.note-box li{margin:4px 0}
.sample-table{width:100%;border-collapse:collapse;font-size:13.5px;margin-top:10px}
.sample-table th,.sample-table td{border:1px solid var(--border);padding:8px 10px;text-align:left;vertical-align:top}
.sample-table th{background:var(--surface-muted);color:var(--ink)}
@media(max-width:850px){.paper-fields{grid-template-columns:1fr 1fr}.panel,.md-view{padding:16px}}
"""

MODULES = dict(zip(
    "01_literature 02_data 03_methods 04_code 05_outputs 06_paper 07_logs".split(),
    "文献 数据 方法 代码 结果 论文 日志".split()
))

RESOURCE_GROUPS = [
    ("01_研究讲义", "研究讲义（PDF 核心教材）", "全书 149 页排版版：导论、1–9 章、终章、附录 A–G 与参考文献。"),
    ("02_中英文顶刊数据库", "中英文顶刊语料数据库", "近三年顶刊标题、摘要 CSV 与选题分布图表，供发现论文与定位空白。"),
    ("03_优秀实证研究范文", "精选前沿工作论文范文", "7 篇公开前沿工作论文 PDF（含典型事实、理论+实证、Shift-Share 与 AI 学习惩罚等）。"),
    ("04_其他科研参考资料", "拓展参考资料", "课外选读网址导航与延伸资源。"),
]

STAGES = [
    ("workshop", "选题与文献", "第 1–2 章"),
    ("stage-data", "数据与变量", "第 3 章"),
    ("stage-methods", "研究设计与模型", "第 4 章"),
    ("stage-analysis", "实证分析与检验", "第 5、8 章"),
    ("stage-paper", "论文与研究表达", "第 6、9 章"),
]

STAGE_GUIDES = [
    (
        "stage-data",
        "阶段 2：数据与变量",
        "第 3 章 · 寻找数据、构造变量与保证数据质量",
        "02_data",
        "明确观测单位、核实数据覆盖年份、完成“体检式描述性统计”与服务理论机制的“典型事实刻画”。",
        [
            "确定主键（如 企业ID-年份、城市-年份），核查重复键与多表合并匹配率，排查未匹配样本是否集中于特定群体。",
            "区分“体检用描述性统计”与“认识问题/服务理论机制的典型事实刻画”（参考范文 Brynjolfsson et al. 2025 与 Dalton et al. 2026）。",
            "若使用文本/大模型构造变量，必须人工抽检验证并与已有成熟测度做交叉校准。",
        ],
        "请阅读讲义第 3 章和当前 research/topic.md，帮我核查目前候选问题对应的数据来源、观测单位与可行性，先列出需要检查的字段清单与潜在缺失风险，待我确认后再写清洗与体检脚本。",
        "变量字典（如 var_dict.md）、数据体检报告与图表（也可放入 05_outputs/）、处理后可复现清洗脚本（放入 04_code/）。",
    ),
    (
        "stage-methods",
        "阶段 3：研究设计与模型",
        "第 4 章 · 选择研究路径、非强因果设计与预承诺",
        "03_methods",
        "先看研究问题适合哪种严肃路径，再锁定核心比较来源、识别假设与“停止规则”。",
        [
            "不必所有选题都硬凑强因果（DID/IV）：4.2 节专门讲清了“理论假说 + 实证检验”（如 Eisfeldt et al. 2026）与“新现象典型事实刻画”（如 Dalton et al. 2026）同样可做严肃设计。",
            "若采用简约式因果（FE/IV/DID/RD），必须写清核心比较来源、聚类层级、防止误放政策后控制变量，并事前设定“停止规则”。",
            "按需要建立 research/plan.md，把基准设定、诊断证据与竞争性解释事前写定。",
        ],
        "请结合 research/topic.md 与第 4 章框架，先比较我的问题更适合“典型事实刻画”“理论+实证”还是“简约式因果识别”，给出备选设计方案、核心假设和一条竞争性解释，等我拍板后写入 research/03_methods/。",
        "研究设计说明（或 research/plan.md）、基准回归方程设定与事前预承诺清单。",
    ),
    (
        "stage-analysis",
        "阶段 4：实证分析与检验",
        "第 5、8 章 · 基准估计、诊断检查与代码一致性核查",
        "05_outputs",
        "先跑干净的基准证据与核心诊断，严禁“看显著性反复挑设定”的隐蔽 p-hacking。",
        [
            "不仅汇报系数与星号，更要核查经济量级（1 个标准差变化带来多少变动）、置信区间与稳健性边界。",
            "按第 5.2 节分寸写清结论措辞：相关性发现 / 机制相容证据 / 强因果结论，绝不越界拔高。",
            "对照第 8 章抽查代码与回归输出数字是否完全一致，关键主回归能用独立方式交叉核验。",
        ],
        "请先阅读 research/plan.md（或 research/03_methods/）与第 5 章纪律，对照既定设计编写可复现运行脚本并输出基准结果表与诊断图，严禁自行增删控制变量迎合显著性；运行后把关键输出与异常一并汇报给我。",
        "回归表与图表输出（放入 05_outputs/，PNG 图表会在此页面直接预览）、对应可复现脚本（放入 04_code/）。",
    ),
    (
        "stage-paper",
        "阶段 5：论文与研究表达",
        "第 6、9 章 · 结构剪裁、对抗式盲审与脱 AI 答辩",
        "06_paper",
        "“做出来”和“写成好论文”是两件事：围绕核心故事做减法，并守住离开 AI 后仍能独立讲清的底线。",
        [
            "参考第 6 章对比中英文期刊结构差异：先抓稳核心主线（引言故事、主表呈现、机制证据），无关冗余表挪进附录。",
            "可发起对抗式盲审：让另一段全新对话扮演审稿人挑刺，再对照原文与程序输出逐条核实修订。",
            "答辩自测：不看屏幕与 AI 对话记录，3 分钟口头讲清问题增量、识别来源、主要局限与为什么不敢下更强结论。",
        ],
        "请基于 research/05_outputs/ 里的真实程序结果与第 6 章规范，先帮我梳理一份“正文主线与图表取舍提纲”（暂不直接写全文），标出每条结论对应的图表编号和需要降调的措辞，待我确认后起草。",
        "论文提纲、草稿版本（放入 06_paper/）、修订记录与研究复盘日志（放入 07_logs/）。",
    ),
]

COLUMNS = "作者与年份 论文标题 研究问题 数据 方法 主要发现 研究局限 与当前研究的关系 来源 核验状态 主题或关键词".split()
TOPIC = RESEARCH / "topic.md"
MATRIX = RESEARCH / "01_literature/matrix.csv"
STEPS = [
    ("观察经济现象", "发生了什么，涉及哪些经济主体？为什么值得解释？哪些事实已有依据？",
     ("研究领域或兴趣", "初步经济现象", "研究动机"), ("重要性",), ("02_data",)),
    ("提出初步研究问题", "要解释谁的什么结果？目的是描述、测量、预测还是识别因果？可以怎样缩小范围？",
     ("当前研究问题", "研究目标"), (), ("03_methods",)),
    ("检索与梳理文献", "哪些研究最接近？它们使用了什么数据与方法，结论和解释在哪些地方有分歧？",
     ("已有文献和潜在贡献",), (), ("01_literature",)),
    ("寻找潜在研究增量", "已有文献解释到哪一步？新的数据、测量、识别机会或经济机制能推进哪一步？依据是什么？",
     ("已有文献和潜在贡献",), ("潜在贡献",), ("01_literature", "03_methods")),
    ("评估研究可行性", "能获取哪些数据？核心变量能否可靠测量？比较对象与主要识别威胁是什么？工作量可承担吗？",
     ("数据与变量的初步设想", "可能的研究方法"), ("数据可行性", "设计可行性"), ("02_data", "03_methods")),
    ("形成初步选题方案", "能否用已有证据讲清问题、动机、核心文献、贡献和研究设计？哪些判断还需要验证？",
     ("当前研究问题", "研究动机", "核心文献", "已有文献和潜在贡献", "数据与变量的初步设想", "可能的研究方法"),
     (), ("01_literature", "02_data", "03_methods")),
]

TASK_DEFAULT_PROMPT = (
    "请阅读 {task_path} 和工作台基础文件（README.md、AGENTS.md、STATUS.md、research/topic.md），"
    "先从第 1 步开始，等我回答再推进下一步。"
)
RESUME_PROMPT = (
    "请先阅读 README.md、AGENTS.md、STATUS.md 和 research/topic.md，核对当前研究问题、进度和已保存文件，"
    "告诉我当前最大的未决问题和建议先推进的一件事；待我确认后继续推进并更新 index.html。"
)


def headings(content):
    """Yield ATX headings outside fenced code blocks, with text offsets."""
    fence = ""
    offset = 0
    for line in content.splitlines(keepends=True):
        start = offset
        offset += len(line)
        marker = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", line.rstrip("\n"))
        if marker:
            run, tail = marker.groups()
            if not fence:
                fence = run
            elif run.startswith(fence) and not tail.strip():
                fence = ""
            continue
        if not fence:
            match = re.match(r"^ {0,3}(#{1,6})[ \t]+(.+?)\s*$", line)
            if match:
                title = re.sub(r"[ \t]+#+$", "", match[2]).strip()
                yield len(match[1]), title, start, offset


def section_blocks(content, level, marks):
    selected = [m for m in marks if m[0] == level]
    prefix = content[:selected[0][2]] if selected else content
    ends = [m[2] for m in selected[1:]] + [len(content)]
    return prefix.strip(), [(m[1], content[m[3]:end].strip()) for m, end in zip(selected, ends)]


def sections(content, level, filename, required=()):
    marks = list(headings(content))
    for name in required:
        levels = [depth for depth, title, _, _ in marks if title == name]
        if not levels or any(depth != level for depth in levels):
            reason = "标题层级有误" if levels else "缺少标题"
            raise ValueError(f"{filename} {reason}「{name}」，请恢复为独立一行「{'#' * level} {name}」后重新运行。")
    result = {}
    for name, body in section_blocks(content, level, marks)[1]:
        if name in result:
            raise ValueError(f"{filename} 重复定义「{'#' * level} {name}」，请合并两处内容并保留一个标题后重新运行。")
        result[name] = body
    return result


def read_sections(path, required):
    return sections(path.read_text(encoding="utf-8-sig"), 2, path.relative_to(ROOT), required)


def fields(pairs):
    return "<dl>" + "".join(f"<dt>{escape(k)}</dt><dd>{escape(v or '待核实')}</dd>" for k, v in pairs) + "</dl>"


def card(label, text):
    return f'<article class="box"><h3>{label}</h3><div class="lines">{escape(text or "待核实")}</div></article>'


def href(path):
    return quote(path.relative_to(ROOT).as_posix())


def file_link(path, label):
    return f'<a href="{href(path)}">{escape(label)}</a>'


def inventory(folder):
    paths = []
    if not folder.exists():
        return paths
    for base, dirs, names in os.walk(folder):
        dirs[:] = [n for n in dirs if not n.startswith(".") and not (Path(base) / n).is_symlink()]
        for name in names:
            p = Path(base) / name
            if not name.startswith((".", "~$")) and not p.is_symlink() and p.is_file():
                paths.append(p)
    return sorted(paths)


def student_visible_resource(folder_name, p):
    """Hide internal build artifacts and scraper scripts from the student-facing resource drawer."""
    rel = p.relative_to(RESOURCES / folder_name).as_posix()
    if folder_name == "01_研究讲义":
        return p.suffix.lower() == ".pdf"
    if folder_name == "02_中英文顶刊数据库":
        if "/scripts/" in f"/{rel}" or rel.startswith("scripts/") or p.suffix.lower() == ".py":
            return False
        if rel.endswith("README.md"):
            return False
    return True


def inline_md(text):
    """Lightweight safe inline Markdown formatting for embedded task cards."""
    s = escape(text)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    s = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", s)
    return s


def md_to_html(text):
    """Convert structured task-card Markdown into clean HTML without external libraries."""
    lines = text.splitlines()
    out = []
    in_ul = False
    in_ol = False
    in_quote = False
    in_code = False

    def close_blocks():
        nonlocal in_ul, in_ol, in_quote
        if in_ul:
            out.append("</ul>")
            in_ul = False
        if in_ol:
            out.append("</ol>")
            in_ol = False
        if in_quote:
            out.append("</blockquote>")
            in_quote = False

    for raw in lines:
        s = raw.rstrip()
        if s.strip().startswith("```"):
            close_blocks()
            if not in_code:
                in_code = True
                out.append("<pre><code>")
            else:
                in_code = False
                out.append("</code></pre>")
            continue
        if in_code:
            out.append(escape(s))
            continue
        if not s.strip() or s.strip() == "---":
            close_blocks()
            continue
        if s.startswith("# "):
            close_blocks()
            continue
        if s.startswith("## "):
            close_blocks()
            out.append(f"<h2>{inline_md(s[3:].strip())}</h2>")
            continue
        if s.startswith("### "):
            close_blocks()
            out.append(f"<h3>{inline_md(s[4:].strip())}</h3>")
            continue
        if s.startswith("> "):
            if not in_quote:
                close_blocks()
                in_quote = True
                out.append("<blockquote>")
            out.append(f"<p>{inline_md(s[2:].strip())}</p>")
            continue
        m_ol = re.match(r"^\s*\d+\.\s+(.+)$", s)
        if m_ol:
            if in_ul:
                out.append("</ul>")
                in_ul = False
            if in_quote:
                out.append("</blockquote>")
                in_quote = False
            if not in_ol:
                in_ol = True
                out.append("<ol>")
            out.append(f"<li>{inline_md(m_ol.group(1))}</li>")
            continue
        m_ul = re.match(r"^\s*[-*]\s+(.+)$", s)
        if m_ul:
            if in_ol:
                out.append("</ol>")
                in_ol = False
            if in_quote:
                out.append("</blockquote>")
                in_quote = False
            if not in_ul:
                in_ul = True
                out.append("<ul>")
            out.append(f"<li>{inline_md(m_ul.group(1))}</li>")
            continue
        close_blocks()
        out.append(f"<p>{inline_md(s.strip())}</p>")
    close_blocks()
    if in_code:
        out.append("</code></pre>")
    return "\n".join(out)


def source_link(raw):
    try:
        url = urlsplit(raw)
        if (url.scheme.lower() in ("https", "http") and url.hostname and url.username is None
                and not re.search(r'[<>\x22\s\\\x00-\x1f\x7f]', raw)):
            url.port  # Reject malformed ports.
            return f'<a href="{escape(raw)}" target="_blank" rel="noopener noreferrer">{escape(raw)}</a>'
    except ValueError:
        pass
    return escape(raw or "待核实")


def literature():
    records = []
    if MATRIX.exists():
        try:
            with MATRIX.open(encoding="utf-8-sig", newline="") as stream:
                rows = csv.DictReader(stream, strict=True)
                headers = rows.fieldnames or []
                if headers and (not set(headers).intersection(COLUMNS) or len(set(headers)) != len(headers)):
                    raise ValueError("matrix.csv 表头无法识别或有重名列，请对照 README")
                for row in rows:
                    if None in row:
                        raise ValueError(f"matrix.csv 第 {rows.line_num} 行多出字段，请检查逗号和引号")
                    record = {k: (row.get(k) or "").strip() for k in COLUMNS}
                    if any(record.values()):
                        records.append(record)
        except (csv.Error, UnicodeError) as exc:
            raise ValueError(f"research/01_literature/matrix.csv 无法读取，请检查 UTF-8 编码、逗号和双引号（{exc}）。") from exc
    if not records:
        return (
            '<div class="empty">尚未收录文献。第 1 次课后，Agent 会按标准 11 列表头帮你把核验过的文献写入 '
            '<code>research/01_literature/matrix.csv</code>，刷新后即可在这里按作者/关键词检索与展开。'
            '<details><summary>展开查看：填好后的文献矩阵示范样式（不影响你的实际课题）</summary>'
            '<table class="sample-table"><thead><tr><th>作者与年份</th><th>论文标题</th><th>核心研究问题</th><th>方法</th><th>核验状态</th></tr></thead>'
            '<tbody><tr><td>Brynjolfsson, Chandar &amp; Chen (2025)</td><td>Canaries in the Coal Mine? Six Facts about the Recent Employment Effects of AI</td>'
            '<td>生成式 AI 普及后，高暴露职业中的年轻从业者就业是否率先出现下滑？</td><td>高质量行政薪资高频数据 + 典型事实刻画 + 年龄组队列比较</td>'
            '<td>已核对本地工作论文原文</td></tr></tbody></table></details></div>'
        )
    papers = []
    for r in records:
        overview = ("作者与年份", "论文标题", "研究问题", "方法", "核验状态")
        summary = "".join(
            f'<span><small>{k}</small><span class="preview">{escape(r[k] or "待核实")}</span></span>'
            for k in overview
        )
        details = "".join(f"<dt>{k}</dt><dd>{source_link(v) if k=='来源' else escape(v or '待核实')}</dd>"
                          for k, v in r.items())
        papers.append(f'<details class="paper"><summary><span class="paper-fields">{summary}</span></summary>'
                      f'<dl>{details}</dl></details>')
    return (f'<label>筛选文献 <input type="search" id="filter" placeholder="作者、主题或关键词"></label> '
            f'<span role="status" id="matches">{len(records)} 篇</span><div class="papers">{"".join(papers)}</div>')


def timeline(text):
    prefix, versions = section_blocks(text, 3, headings(text))
    result = f'<p class="lines">{escape(prefix)}</p>' if prefix else ""
    for heading, body in versions:
        result += f'<article class="version"><h3>{escape(heading)}</h3><div class="lines">{escape(body.strip())}</div></article>'
    return '<div class="timeline">' + (result or '尚无已确认的选题版本。') + '</div>'


def diagnosis_items(text):
    parts = re.split(r"^(?:[-*] )?(已有依据|待核实问题|下一步)[：:][ \t]*", text, flags=re.M)
    return {key: val.strip() for key, val in zip(parts[1::2], parts[2::2])}


ACTION_HINTS = [
    (("经济现象", "现象的事实"), "找一项可核查的事实，写下涉及的主体、时间及来源。"),
    (("研究对象", "希望比较什么", "问题表述"), "用一句话写清研究对象、结果和想回答的问题。"),
    (("检索词", "检索文献", "代表性论文", "文献矩阵"), "核对最接近的论文，将问题、数据、方法和结论录入文献矩阵。"),
    (("研究增量", "潜在贡献", "竞争性解释"), "对照最接近的研究，写下可能新增的证据和一种竞争性解释。"),
    (("数据字典", "变量测量", "数据可得性", "识别威胁"), "查阅数据字典，核实核心变量的测量方式及样本覆盖。"),
    (("选题方案", "选题提纲"), "把问题、依据和设计写成一段选题说明，并列出仍待核实的判断。"),
]


def status_actions(text):
    actions = {}
    labelled_actions = {}
    for line in text.splitlines():
        task = re.sub(r"^\s*(?:[-*]|\d+[.)、])\s*", "", line).strip()
        for step, (name, *_) in enumerate(STEPS):
            labelled = re.match(re.escape(name) + r"[：:]\s*(.+)", task)
            if labelled:
                labelled_actions.setdefault(step, labelled[1])
                break
        else:
            matches = [i for i, (terms, _) in enumerate(ACTION_HINTS) if any(term in task for term in terms)]
            if len(matches) == 1:
                actions.setdefault(matches[0], task)
    actions.update(labelled_actions)
    return actions


def copy_block(btn_label, prompt_text, btn_class="btn-primary"):
    pid = abs(hash(prompt_text)) % 1000000
    return (
        f'<div class="prompt-box"><code id="p-{pid}">{escape(prompt_text)}</code>'
        f'<button type="button" class="btn {btn_class}" onclick="copyPrompt(\'p-{pid}\', this)">{escape(btn_label)}</button></div>'
    )


def workshop(topic, status, plan_link):
    actions = status_actions(status["下一步"])
    diag = sections(topic["选题诊断"], 3, "research/topic.md 的选题诊断")
    tabs, panels = [], []
    for i, (name, prompt, keys, criteria, modules) in enumerate(STEPS, 1):
        tabs.append(f'<a href="#step-{i}">{i}. {name}</a>')
        material_items = [(k, topic.get(k, "")) for k in keys]
        risks = []
        next_steps = []
        for k in criteria:
            entry = diagnosis_items(diag.get(k, ""))
            material_items.append((k + " · 已有依据", entry.get("已有依据", "")))
            if entry.get("待核实问题"):
                risks.append((k + " · 待核实问题", entry["待核实问题"]))
            if entry.get("下一步") and entry["下一步"].strip("。 ") not in ("待补充", "待核实", "尚未确定"):
                next_steps.append(entry["下一步"])
        action = actions.get(i - 1) or "\n".join(next_steps) or ACTION_HINTS[i - 1][1]
        if not risks or i == 6:
            risks.append(("选题待核实事项", topic.get("重要待核实问题", "")))
        materials = fields(material_items)
        links = [file_link(TOPIC, "研究主题原文")]
        links.extend(f'<a href="#{m}">{MODULES[m]}目录</a>' for m in modules)
        if "01_literature" in modules and MATRIX.is_file():
            links.append(file_link(MATRIX, "文献矩阵原件"))
        if i in (3, 4, 6):
            links.append('<a href="#matrix">跳到文献矩阵</a>')
        if i == 6 and plan_link:
            links.append(plan_link)
        panels.append(
            f'<article id="step-{i}" class="panel"><h2>{i}. {name}</h2><p class="sub">{prompt}</p>'
            f'<div class="action"><strong>当前建议行动</strong>{escape(action)}</div>'
            f'<h3>当前研究材料</h3>{materials}<h3>尚未解决的问题</h3>{fields(risks)}'
            f'<h3>相关文件</h3><div class="refs">{"".join(links)}</div></article>'
        )
    diagnoses = "".join(card(k, v) for k, v in diag.items())
    return (
        f'<section id="workshop"><h1>阶段 1：选题与文献</h1>'
        f'<p class="sub">配套讲义第 1–2 章 · 对应 <a href="#tasks">第 1 次课任务卡</a>。研究允许折返调整，不急于一上来定死唯一题目。</p>'
        f'<nav class="steps" aria-label="选题环节">{"".join(tabs)}</nav>'
        f'{"".join(panels)}<h2>当前研究问题</h2><div class="box lines">{escape(topic["当前研究问题"])}</div>'
        f'<h2 id="matrix">文献矩阵</h2>{literature()}<h2>选题诊断</h2><div class="grid">{diagnoses}</div>'
        f'<h2>研究问题演化</h2>{timeline(topic.get("研究问题演化",""))}</section>'
    )


def render_file_list(key, files):
    items = []
    for p in files:
        name = p.relative_to(RESEARCH / key).as_posix()
        item = file_link(p, name)
        if key == "05_outputs" and p.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".gif"}:
            item += f'<img loading="lazy" alt="{escape(name)}" src="{href(p)}">'
        items.append(f"<li>{item}</li>")
    return '<ul class="files">' + "".join(items) + '</ul>' if items else f'<p class="empty">当前目录 <code>research/{key}/</code> 暂无文件。和 AI 完成相关任务并保存文件后，刷新本页即可看到。</p>'


def stage_pages(files_map):
    out = []
    for sid, title, chapter, folder_key, lead, checklist, prompt_tpl, deliverables in STAGE_GUIDES:
        checks = "".join(f"<li>{escape(c)}</li>" for c in checklist)
        folder_label = MODULES[folder_key]
        out.append(
            f'<section id="{sid}"><h1>{escape(title)}</h1>'
            f'<p class="sub"><span class="pill">{escape(chapter)}</span> &nbsp; 对应存档目录：<code>research/{folder_key}/</code></p>'
            f'<div class="stage-card"><h3>核心任务</h3><p>{escape(lead)}</p>'
            f'<div class="note-box"><strong>零基础推进要点：</strong><ul>{checks}</ul></div>'
            f'<h3>发送给 AI 的本阶段启动指令</h3>{copy_block("复制本阶段指令", prompt_tpl, "btn-primary")}'
            f'<p style="margin-top:12px;color:var(--muted);font-size:14px"><b>预期阶段产出：</b>{escape(deliverables)}</p></div>'
            f'<h2>当前目录已存文件（{folder_label} · {len(files_map[folder_key])} 份）</h2>'
            f'{render_file_list(folder_key, files_map[folder_key])}</section>'
        )
    return "".join(out)


def file_module(key, label, files):
    listing = render_file_list(key, files)
    related = {
        "01_literature": ("matrix", "查看文献矩阵"),
        "04_code": ("05_outputs", "查看分析结果"),
        "05_outputs": ("04_code", "查看分析程序"),
    }
    link = ""
    if key in related:
        target, title = related[key]
        link = f'<div class="btn-row"><a class="btn" href="#{target}">{title} →</a></div>'
    return f'<section id="{key}"><h1>档案目录：{label}（<code>research/{key}/</code>）</h1>{link}<h2>本地文件 · {len(files)} 份</h2>{listing}</section>'


def public_resources():
    cards = []
    for folder_name, label, description in RESOURCE_GROUPS:
        folder = RESOURCES / folder_name
        readme = folder / "README.md"
        all_files = [p for p in inventory(folder) if p != readme]
        files = [p for p in all_files if student_visible_resource(folder_name, p)]
        guide = file_link(readme, "查看目录说明") if readme.is_file() else ""
        if files:
            items = "".join(f'<li>{file_link(p, p.relative_to(folder).as_posix())}</li>' for p in files)
            listing = f'<ul class="files">{items}</ul>'
        else:
            listing = '<p class="empty">资料待添加。</p>'
        cards.append(
            f'<details class="box" {"open" if folder_name in ("01_研究讲义", "03_优秀实证研究范文") else ""}>'
            f'<summary>{escape(label)} · {len(files)} 份</summary>'
            f'<p style="margin-top:6px;color:var(--muted);font-size:14px">{escape(description)}</p>{guide}{listing}</details>'
        )
    return (
        '<div id="public-resources"><h2>公共研究资源（只读参考库）</h2>'
        '<p class="sub">已过滤构建源码与采集脚本，只保留最适合学生阅读与查阅的材料；相关文献证据进入个人矩阵前仍需核实。</p>'
        f'<div class="grid">{"".join(cards)}</div></div>'
    )


def tasks_section(task_files):
    if not task_files:
        return (
            '<section id="tasks"><h1>课堂任务卡</h1>'
            '<p class="empty">当前 <code>tasks/</code> 目录暂无任务卡片。</p></section>'
        )
    cards = []
    for p in task_files:
        raw = p.read_text(encoding="utf-8-sig")
        title_m = re.match(r"^#\s+(.+)$", raw.strip(), flags=re.M)
        title = title_m.group(1).strip() if title_m else p.stem
        rel = p.relative_to(ROOT).as_posix()
        prompt = TASK_DEFAULT_PROMPT.format(task_path=rel)
        cards.append(
            f'<article class="md-view" style="margin-bottom:22px">'
            f'<div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px">'
            f'<span class="pill">{escape(rel)}</span>'
            f'{file_link(p, "打开规程原文（Markdown）")}</div>'
            f'<h1 style="font-size:23px;margin-bottom:10px">{escape(title)}</h1>'
            f'<div><b style="font-size:14px;color:var(--primary)">给 AI 助手发送下面这句即可开始（不需要背，也不用自己敲长指令）：</b>'
            f'{copy_block("复制启动短句", prompt, "btn-primary")}</div>'
            f'<details style="margin-top:16px"><summary>展开查看：发给 Agent 的任务规程原文（透明可查，可按自己课题随时跳步或改道）</summary>'
            f'<div style="margin-top:12px">{md_to_html(raw)}</div></details></article>'
        )
    return (
        '<section id="tasks"><h1>课堂任务卡（示范起步 · 鼓励个性化探索）</h1>'
        '<div class="note-box"><strong>使用说明（请先看这一段）：</strong>'
        '下面的任务卡只是课程前期帮你和 AI 顺利搭话的<b>一套起步示范</b>，<b>不是统一模板，也不是唯一的标准答案</b>。'
        '真实研究中，欢迎你完全基于自己的生活观察、专业兴趣、实习感受或手头数据来发问和调整路线——哪怕绕开卡片、中途推翻想法，只要在认真思考并如实留痕，都是极好的研究状态。</div>'
        f'{"".join(cards)}'
        '<div class="stage-card"><h3>下课前留给自己（而不是给 AI）的 3 个自检问题</h3>'
        '<ol style="margin:8px 0 0;padding-left:20px">'
        '<li><b>离开屏幕能讲清吗？</b>不看 AI 对话框，用 1 分钟口头说说：你关注什么现实问题、准备比谁和谁？</li>'
        '<li><b>文献核验诚实吗？</b>打开「选题与文献」里的文献矩阵，确认只看了摘要的论文没有被误写成“已核对全文”。</li>'
        '<li><b>留了推翻的余地吗？</b>允许今天仍保留 2 个待比较方向或记下“为什么放弃了某个空洞想法”，这比硬定一个假大空题目更有价值。</li>'
        '</ol></div></section>'
    )


def guide_section():
    return (
        '<section id="guide"><h1>零基础使用指南与填表示例</h1>'
        '<p class="sub">把工作台想象成：<b>一个科研专用文件夹 + 一位听你指挥的数字研究助理 + 一块双击就能看的进度看板</b>。不需要记命令，也不用怕点坏东西。</p>'
        '<div class="grid">'
        '<article class="box"><h3>1. 我每次打开要干什么？</h3><div class="lines">① 双击项目里的 <b>index.html</b> 查看自己做到哪一步；\n② 用支持本地读写的 AI 工具打开整个项目文件夹；\n③ 复制「课堂任务卡」或「恢复工作」指令发给 AI。</div></article>'
        '<article class="box"><h3>2. 不会用终端敲命令怎么办？</h3><div class="lines">不用自己敲命令！只要在对话结尾加上：<i>“更新文件后顺便帮我运行 build_dashboard.py 刷新首页。”</i> AI 会替你跑完脚本，你只需刷新浏览器看新结果。</div></article>'
        '<article class="box"><h3>3. 我和 AI 谁说了算？</h3><div class="lines">AI 是你的专业研究助理（负责检索、整理、写代码、跑图表与归档），<b>选题方向、样本口径、方法选择、结论措辞的拍板权永远在你手里</b>。</div></article>'
        '</div>'
        '<h2>四个核心文件各自管什么？</h2>'
        '<div class="box"><table class="sample-table"><thead><tr><th>文件/目录</th><th>通俗理解</th><th>谁来改 / 何时看</th></tr></thead>'
        '<tbody><tr><td><code>research/topic.md</code></td><td>你的<b>选题笔记本</b>（记录观察到的现象、候选问题、选题诊断与演化版本）</td><td>和 AI 讨论确认后由 AI 写入；你随时可在网页「选题与文献」查看</td></tr>'
        '<tr><td><code>research/01_literature/matrix.csv</code></td><td>你的<b>文献对比大表</b>（11 个固定字段，含核验状态）</td><td>核对文献后逐条录入；可在网页搜索框按作者/主题筛选展开</td></tr>'
        '<tr><td><code>STATUS.md</code></td><td>工作台的<b>进度备忘录</b>（记住上次停在哪、下周第一步做什么）</td><td>每次结束工作前更新，确保换个工具或隔一周回来都能无缝接续</td></tr>'
        '<tr><td><code>research/07_logs/</code></td><td>你的<b>研究日记本</b>（记录为什么淘汰某个题目、排除了什么数据坑）</td><td>建议按 <code>YYYY-MM-DD-主题.md</code> 保存有后续价值的决策</td></tr></tbody></table></div>'
        '<h2>另起新课题 / 对外分享前必查</h2>'
        '<div class="note-box"><b>不要直接覆盖旧课题：</b>新研究只需先整体复制一份项目文件夹副本，让 AI 协助清空/归档旧的 <code>research/</code> 内容再重新开始。发给老师或同学前，检查不要误打包受版权或保密协议限制的原始数据与密钥。</div>'
        '</section>'
    )


def recent(files):
    entries = []
    logs = sorted((p for p in files if p.suffix.lower() == ".md"), key=lambda p: p.name, reverse=True)
    for p in logs[:5]:
        with p.open(encoding="utf-8-sig") as f:
            excerpt = next((line.strip() for line in f if line.strip() and not line.startswith("#")), "")
        entries.append(f'<li>{file_link(p, p.stem)}<p style="color:var(--muted);font-size:14px;margin-top:3px">{escape(excerpt[:240])}</p></li>')
    return '<ul class="files">' + "".join(entries) + '</ul>' if entries else '<p class="empty">尚无研究日志。第 1 次课后可让 AI 帮你记下第一条选题排查日志（保存在 <code>research/07_logs/</code>）。</p>'


JS = r"""
const pages = [...document.querySelectorAll('main > section')];
const steps = [...document.querySelectorAll('.panel')];
function navigate() {
  const id = location.hash.slice(1);
  const step = id === 'matrix' ? steps[2] : steps.find(p => p.id === id);
  const page = pages.find(p => p.id === id) || (step ? document.getElementById('workshop') : pages[0]);
  pages.forEach(p => p.hidden = p !== page);
  const current = step || steps[0];
  steps.forEach(p => p.hidden = p !== current);
  document.querySelectorAll('aside a, .steps a').forEach(a => {
    if (a.hash === '#' + page.id) a.setAttribute('aria-current','page');
    else if (current && a.hash === '#' + current.id) a.setAttribute('aria-current','step');
    else a.removeAttribute('aria-current');
  });
  if (id === 'matrix') document.getElementById('matrix').scrollIntoView();
  else window.scrollTo(0,0);
}
window.addEventListener('hashchange', navigate);
navigate();
const filter = document.getElementById('filter');
if (filter) filter.addEventListener('input', () => {
  const terms = filter.value.trim().toLowerCase().split(/\s+/);
  let count = 0;
  document.querySelectorAll('.paper').forEach(paper => {
    const text = Array.from(paper.querySelectorAll('dd'), d => d.textContent).join(' ').toLowerCase();
    paper.hidden = !terms.every(term => text.includes(term));
    if (!paper.hidden) count++;
  });
  document.getElementById('matches').textContent = count ? count + ' 篇' : '没有匹配的文献';
});
function copyPrompt(elemId, btn) {
  const el = document.getElementById(elemId);
  if (!el) return;
  const text = el.textContent;
  const done = () => {
    const old = btn.textContent;
    btn.textContent = '已复制，去粘贴给 AI 吧';
    setTimeout(() => { btn.textContent = old; }, 2200);
  };
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(done).catch(() => fallbackCopy(text, done));
  } else {
    fallbackCopy(text, done);
  }
}
function fallbackCopy(text, cb) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); cb(); } catch(e) {}
  document.body.removeChild(ta);
}
"""


def render():
    status = read_sections(ROOT / "STATUS.md", ("当前阶段", "当前研究问题", "已经完成", "尚未解决", "下一步"))
    topic = read_sections(TOPIC, ("当前研究问题", "研究动机", "研究问题演化", "选题诊断"))
    plan = RESEARCH / "plan.md"
    plan_link = file_link(plan, "查看研究计划") if plan.is_file() else ""
    files = {k: inventory(RESEARCH / k) for k in MODULES}
    task_files = [p for p in inventory(TASKS_DIR) if p.suffix.lower() == ".md"]

    module_nav = "".join(
        f'<a href="#{k}">{v} <span class="nav-count">{len(files[k])}</span></a>'
        for k, v in MODULES.items()
    )
    tiles = "".join(f'<a href="#{k}"><b>{v}</b><small>{len(files[k])} 份文件</small></a>' for k, v in MODULES.items())
    flow = "".join(
        f'<a class="stage" href="#{sid}"><small>STAGE 0{i}</small><b>{escape(name)}</b><span class="stage-ch">{escape(ch)}</span></a>'
        for i, (sid, name, ch) in enumerate(STAGES, 1)
    )
    state = card("已完成的工作", status["已经完成"]) + card("尚未解决 / 当前卡点", status["尚未解决"])
    if status.get("已核实的重要发现"):
        state = card("已核实的重要发现", status["已核实的重要发现"]) + state

    is_fresh = topic["当前研究问题"].strip("。 ") in ("尚未确定", "待补充", "")
    first_task = task_files[0] if task_files else None
    first_prompt = (
        TASK_DEFAULT_PROMPT.format(task_path=first_task.relative_to(ROOT).as_posix())
        if first_task else RESUME_PROMPT
    )

    onboard_inner = (
        '<div class="onboard-head"><div><span class="pill">零基础快速开箱 · 3 步开始</span>'
        '<h3 style="margin-top:8px;font-size:17px">第一次打开工作台？照着下面三步做就行（全程不用写代码）</h3></div>'
        '<a class="btn btn-slate" href="#tasks">查看第 1 次课任务卡 →</a></div>'
        '<div class="quick-steps">'
        '<div class="qstep"><span class="step-num">STEP 01</span><b>先看 1 份核心材料</b><p>打开下方<b>《完整课程讲义 PDF》</b>，课前先读《导论》与附录 F。</p></div>'
        '<div class="qstep"><span class="step-num">STEP 02</span><b>用 AI 打开本文件夹</b><p>用支持本地文件的 AI 助手打开整个工作台根目录。</p></div>'
        '<div class="qstep"><span class="step-num">STEP 03</span><b>复制下方指令开聊</b><p>发给 AI 后跟着任务卡走，AI 刷新页面后你回浏览器按 F5 即可。</p></div>'
        '</div>'
        '<div style="font-size:13.5px;font-weight:650;color:var(--ink)">点击右侧按钮复制「第 1 次课启动指令」：</div>'
        f'{copy_block("复制第 1 次课指令", first_prompt, "btn-primary")}'
    )
    onboard_block = (
        f'<div class="onboard">{onboard_inner}</div>'
        if is_fresh else
        f'<details class="onboard" style="padding:14px 20px"><summary>查看新手快速启动说明与第 1 次课任务卡入口</summary><div style="margin-top:12px">{onboard_inner}</div></details>'
    )

    lecture_pdf = RESOURCES / "01_研究讲义/AI时代的经济学实证研究_完整讲义.pdf"
    reading_html = RESOURCES / "04_其他科研参考资料/AI与经济学实证研究_课外选读.html"
    shortcuts = (
        '<div class="shortcut-grid">'
        + (f'<a class="shortcut-card" href="{href(lecture_pdf)}"><span class="pill" style="align-self:flex-start">核心教材 PDF</span><b>完整课程讲义（149 页）</b><span class="desc">导论、1–9 章、终章、附录 A–G 与参考文献</span><span class="cta">阅读讲义 →</span></a>' if lecture_pdf.is_file() else "")
        + '<a class="shortcut-card" href="#tasks"><span class="pill" style="align-self:flex-start">上课带练必备</span><b>课堂任务卡片（白盒引导）</b><span class="desc">点开看每一步流程并一键复制发给 AI</span><span class="cta">打开任务卡 →</span></a>'
        + '<a class="shortcut-card" href="#public-resources"><span class="pill" style="align-self:flex-start">文献与语料库</span><b>7 篇工作论文范文 + 顶刊数据库</b><span class="desc">已隐藏构建源码，直接阅读公开 PDF 与题录</span><span class="cta">浏览资料 →</span></a>'
        + (f'<a class="shortcut-card" href="{href(reading_html)}"><span class="pill" style="align-self:flex-start">拓展阅读</span><b>课外选读与工具导航</b><span class="desc">国内外 AI × 经济学研究精选资源</span><span class="cta">查看选读 →</span></a>' if reading_html.is_file() else "")
        + '</div>'
    )

    generated = datetime.now().strftime("%Y-%m-%d %H:%M")
    home = f"""<section id="overview">
    <h1>研究概况</h1>
    {onboard_block}
    <div class="hero">
      <span class="hero-kicker">{escape(status['当前阶段'])}</span>
      <p style="margin-top:8px;color:var(--muted);font-size:13.5px">当前研究问题</p>
      <strong>{escape(topic['当前研究问题'])}</strong>
      <div class="hero-meta">研究目标：{escape(topic.get('研究目标') or '尚未明确（欢迎先通过第 1 次课任务卡探索 2–3 个候选方向）')}</div>
      <div class="btn-row">
        <a class="btn btn-primary" href="#workshop">进入选题与文献 →</a>
        <a class="btn btn-slate" href="#tasks">打开课堂任务卡</a>
        {plan_link}
      </div>
    </div>
    <h2>课前与上课直达入口</h2>
    {shortcuts}
    <h2>研究流程（五个可往返阶段）</h2>
    <div class="flow">{flow}</div>
    <h2>当前进展与卡点</h2>
    <div class="grid">{state}</div>
    <h2>下一步行动</h2>
    <div class="box lines">{escape(status['下一步'])}</div>
    <h2>恢复研究工作指令</h2>
    {copy_block("复制恢复工作指令", RESUME_PROMPT, "btn-slate")}
    <h2>最近研究日志</h2>
    {recent(files['07_logs'])}
    <h2>我的研究档案（<code>research/</code>）</h2>
    <div class="resources">{tiles}</div>
    {public_resources()}
    <footer class="generated">工作台最后生成：{generated} ｜ 若让 AI 更新了文档或数据，让它顺手运行 <code>python3 scripts/build_dashboard.py</code> 后刷新本页面即可。</footer>
    </section>"""

    modules = "".join(file_module(k, v, files[k]) for k, v in MODULES.items())
    shell = (
        SHELL.replace("@EXTRA_CSS@", CSS)
        .replace("@TASK_COUNT@", str(len(task_files)))
        .replace("@MODULE_NAV@", module_nav)
    )
    return shell + home + tasks_section(task_files) + guide_section() + workshop(topic, status, plan_link) + stage_pages(files) + modules + '</main></div><script>' + JS + '</script></body></html>\n'


def main():
    page = render()
    output = ROOT / "index.html"
    temp = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=ROOT, delete=False) as f:
            temp = Path(f.name)
            f.write(page)
        temp.replace(output)
    finally:
        if temp and temp.exists():
            temp.unlink()
    print("已生成 index.html，请刷新浏览器。")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, OSError, csv.Error) as exc:
        sys.exit(f"生成失败，请检查源文件：{exc}")