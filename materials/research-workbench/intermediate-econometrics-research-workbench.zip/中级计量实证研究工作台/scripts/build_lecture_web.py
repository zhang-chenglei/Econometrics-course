#!/usr/bin/env python3
"""把讲义各章 Markdown 合成为可在线阅读的单文件网页版。

用法（在工作台根目录）：
    python3 scripts/build_lecture_web.py
    python3 scripts/build_lecture_web.py /path/to/讲义源码目录

依赖：pandoc（--mathml 输出离线可渲染的公式，无需联网、无需 JS）。
输出：resources/01_研究讲义/AI时代的经济学实证研究_网页版.html
"""

from __future__ import annotations

import base64
import html
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUTPUT = ROOT / "resources/01_研究讲义/AI时代的经济学实证研究_网页版.html"
DEFAULT_SOURCE = Path.home() / "Documents/EconKB/30_教学/09_计量教材/AI时代的经济学实证研究_讲义源码"

# (key, 侧栏短标题, 源文件)；顺序即阅读顺序
CHAPTERS = [
    ("ch00", "导论", "00_导论_AI时代如何成为一名经济学研究者.md"),
    ("ch01", "第 1 章　发现值得研究的问题", "01_第1章_如何发现值得研究的经济学问题.md"),
    ("ch02", "第 2 章　检索与评述文献", "02_第2章_如何检索阅读和评述学术文献.md"),
    ("ch03", "第 3 章　数据与变量", "03_第3章_如何寻找数据构造变量并保证数据质量.md"),
    ("ch04", "第 4 章　研究方法与设计", "04_第4章_如何选择研究方法与设计可信的实证研究.md"),
    ("ch05", "第 5 章　实证分析与解释", "05_第5章_如何开展实证分析与解释研究结果.md"),
    ("ch06", "第 6 章　写成学术论文", "06_第6章_如何将研究结果写成学术论文.md"),
    ("ch07", "第 7 章　让 Agent 做研究", "07_第7章_如何让Agent更好地完成研究任务.md"),
    ("ch08", "第 8 章　审查 Agent 的工作", "08_第8章_如何审查Agent的研究工作.md"),
    ("ch09", "第 9 章　用 Agent 提升能力", "09_第9章_如何利用Agent不断提高自己的研究能力.md"),
    ("ch10", "终章　重新理解研究", "10_终章_在AI时代重新理解学习研究工作与生活.md"),
    ("ch11", "附录　数据库与工作台", "10_附录_数据库示例清单与工作台指南.md"),
    ("ch12", "参考文献", "11_参考文献.md"),
]

CSS = """
:root{
  --bg:#eef1f5; --paper:#ffffff; --surface:#ffffff; --surface-muted:#f8fafc; --surface-subtle:#f1f5f9;
  --ink:#0f172a; --muted:#475569; --border:#e2e8f0;
  --primary:#c8102e; --primary-soft:rgba(200,16,46,.07); --primary-ring:rgba(200,16,46,.22);
  --h3:#1d4ed8; --h4:#0f766e;
  --reading:18px;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--ink);font-family:-apple-system,"PingFang SC","Helvetica Neue",Arial,sans-serif;-webkit-font-smoothing:antialiased}
a{color:var(--primary);text-decoration:none}
a:hover{text-decoration:underline}

.layout{display:grid;grid-template-columns:296px minmax(0,1fr);min-height:100vh}
aside{position:sticky;top:0;height:100vh;overflow:auto;background:var(--surface-muted);border-right:1px solid var(--border);padding:22px 18px 40px;z-index:30}
.brand{display:flex;align-items:center;gap:10px;margin-bottom:6px}
.brand-mark{width:30px;height:30px;border-radius:8px;background:var(--primary);color:#fff;display:grid;place-items:center;font-weight:700;font-size:15px;flex:none}
.brand b{font-size:15.5px;line-height:1.3}
.brand-sub{color:var(--muted);font-size:12px;margin:2px 0 16px 40px;line-height:1.5}
.search{width:100%;padding:8px 11px;border:1px solid var(--border);border-radius:9px;font:inherit;font-size:13.5px;background:var(--surface);margin-bottom:14px}
.search:focus{outline:none;border-color:var(--primary-ring);box-shadow:0 0 0 3px var(--primary-soft)}
nav h3{font-size:11.5px;letter-spacing:.1em;color:var(--muted);margin:0 0 8px 4px;font-weight:650}
nav ol{list-style:none;margin:0;padding:0}
nav li{margin:1px 0}
nav a.chap{display:block;padding:7px 10px;border-radius:8px;color:var(--ink);font-size:14px;line-height:1.45}
nav a.chap:hover{background:var(--surface-subtle);text-decoration:none}
nav a.chap[aria-current=page]{background:var(--primary);color:#fff;font-weight:600}
nav ol.sub{margin:2px 0 8px;padding:0 0 0 14px;border-left:1px solid var(--border);display:none}
nav li.active ol.sub{display:block}
nav ol.sub a{display:block;padding:4px 8px;font-size:12.8px;color:var(--muted);border-radius:6px;line-height:1.45}
nav ol.sub a:hover{color:var(--primary);background:var(--surface-subtle);text-decoration:none}
.side-foot{margin-top:22px;padding-top:14px;border-top:1px solid var(--border);font-size:12.5px;color:var(--muted);line-height:1.9}
.side-foot a{display:block}

main{min-width:0;padding:0 0 70px}
.bar{position:sticky;top:0;z-index:10;display:flex;align-items:center;gap:10px;padding:10px 22px;background:rgba(255,255,255,.94);backdrop-filter:blur(10px);border-bottom:1px solid var(--border)}
.crumb{font-size:13px;color:var(--muted);flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.crumb a{color:var(--muted)}
.crumb b{color:var(--ink);font-weight:650}
.pageinfo{font-size:12.5px;color:var(--muted);font-variant-numeric:tabular-nums;padding:0 4px;display:none}
body.present .pageinfo{display:inline}
.tools{display:flex;align-items:center;gap:6px;flex:none}
.tools button,.pager button{border:1px solid var(--border);background:var(--surface);border-radius:8px;padding:6px 10px;font:inherit;font-size:13px;color:var(--ink);cursor:pointer;line-height:1.2}
.tools button:hover,.pager button:hover:not(:disabled){border-color:var(--primary-ring);color:var(--primary)}
.pager button:disabled{opacity:.35;cursor:default}
.pager{display:flex;gap:6px}
#menu{display:none}

.stage{padding:26px 30px 0}
article{display:none;max-width:860px;margin:0 auto;background:var(--paper);border:1px solid var(--border);border-radius:18px;padding:54px 62px 58px;box-shadow:0 1px 2px rgba(15,23,42,.04),0 14px 40px rgba(15,23,42,.07)}
article.active{display:block}
article h1{font-size:30px;line-height:1.35;margin:0 0 28px;letter-spacing:.01em;padding-bottom:16px;border-bottom:2px solid var(--primary);color:var(--ink)}
article h2{font-size:21px;margin:44px 0 16px;padding-left:13px;border-left:5px solid var(--primary);line-height:1.45;color:var(--primary)}
article h3{font-size:18px;margin:30px 0 10px;color:var(--h3)}
article h4{font-size:16.5px;margin:22px 0 8px;color:var(--h4)}
article p,article li{font-family:"Songti SC","STSong","Times New Roman",serif;font-size:var(--reading);line-height:2;color:#16202e}
article p{margin:0 0 14px;text-align:justify;text-indent:2em}
article li p{text-indent:0}
article ul,article ol{padding-left:26px;margin:0 0 16px}
article li{margin:6px 0}
article blockquote{margin:22px 0;padding:13px 20px;background:var(--surface-muted);border-left:3px solid var(--primary-ring);border-radius:0 8px 8px 0}
article blockquote p{margin:0;text-indent:0;font-size:calc(var(--reading) - 1px);color:var(--muted)}
article hr{border:none;border-top:1px solid var(--border);margin:36px 0}
article code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:.9em;background:var(--surface-subtle);padding:1.5px 5px;border-radius:5px}
article pre{background:var(--surface-subtle);padding:14px 16px;border-radius:10px;overflow:auto;font-size:13.5px;line-height:1.7}
article pre code{background:none;padding:0}
.tw{overflow-x:auto;margin:20px 0;border:1px solid var(--border);border-radius:10px}
article table{border-collapse:collapse;width:100%;font-size:14.5px;background:var(--surface)}
article th,article td{padding:9px 12px;border-bottom:1px solid var(--border);text-align:left;vertical-align:top;line-height:1.65}
article th{background:var(--surface-muted);font-weight:650;white-space:nowrap}
article tr:last-child td{border-bottom:none}
article img{max-width:100%;height:auto;border:1px solid var(--border);border-radius:8px;background:#fff;display:block;margin:22px auto 8px}
article math{font-size:1.04em}
.endnav{max-width:860px;margin:22px auto 0;padding:0 30px;display:flex;justify-content:space-between;gap:10px}
.endnav a{flex:1;padding:14px 18px;border:1px solid var(--border);border-radius:12px;font-size:14px;color:var(--ink);background:var(--surface)}
.endnav a:hover{border-color:var(--primary-ring);text-decoration:none;color:var(--primary)}
.endnav small{display:block;color:var(--muted);font-size:11.5px;margin-bottom:3px}
.endnav .next{text-align:right}
.foot{max-width:860px;margin:24px auto 0;padding:0 30px;color:#64748b;font-size:12.5px;line-height:1.7}

/* ============ 全屏演示：左目录 + 右分页，不滚动 ============ */
body.present{background:#e3e7ec}
body.present .layout{grid-template-columns:268px minmax(0,1fr)}
body.present aside{display:block;position:sticky;top:0;width:268px;height:100vh;padding:18px 14px 30px}
body.present aside .brand b{font-size:14.5px}
body.present main{padding:0;height:100vh;overflow:hidden;display:flex;flex-direction:column}
body.present .bar{padding:8px 16px;flex:none}
body.present .stage{flex:1;min-height:0;padding:14px 18px 18px;overflow:hidden}
body.present article{display:none;height:100%;max-width:1180px;margin:0 auto;padding:34px 48px;border-radius:14px;overflow:hidden;position:relative}
body.present article.active{display:block}
body.present .flow{height:100%;column-fill:auto;column-gap:60px;transition:transform .22s cubic-bezier(.3,0,.2,1);will-change:transform}
body.present .flow li,body.present .flow figure{break-inside:avoid-column}
body.present .flow .tw{overflow:visible;break-inside:auto;max-width:100%}
body.present .flow table{font-size:calc(var(--reading) * 0.66);break-inside:auto}
body.present .flow th{white-space:normal}
body.present .flow tr{break-inside:avoid-column}
body.present .flow thead{display:table-header-group}
body.present .flow h1,body.present .flow h2,body.present .flow h3,body.present .flow h4{break-after:avoid-column;break-inside:avoid-column}
body.present article h1{font-size:31px;margin-bottom:20px;padding-bottom:12px}
body.present article h2{font-size:23px;margin:26px 0 12px}
body.present article h3{font-size:19px;margin:18px 0 8px}
body.present article p,body.present article li{font-size:calc(var(--reading) * 1.12);line-height:2}
body.present .endnav,body.present .foot{display:none}
body.present #menu{display:none}

@media(max-width:980px){
  .layout{grid-template-columns:minmax(0,1fr)}
  aside{display:none;position:fixed;top:0;left:0;width:340px;max-width:88vw;height:100vh;box-shadow:0 0 40px rgba(15,23,42,.18)}
  aside.open{display:block}
  body.present aside{position:fixed;width:340px;max-width:88vw;box-shadow:0 0 40px rgba(15,23,42,.18)}
  body.present aside:not(.open){display:none}
  body.present #menu{display:inline-flex;align-items:center;gap:5px}
  #menu{display:inline-flex;align-items:center;gap:5px;border:1px solid var(--border);background:var(--surface);border-radius:8px;padding:6px 10px;font:inherit;font-size:13px;cursor:pointer}
  .bar{padding:9px 14px;gap:8px}
  .pager button,.tools button{padding:5px 8px;font-size:12.5px}
  .stage{padding:14px 12px 0}
  body.present .stage{padding:10px}
  article{padding:26px 20px 30px;border-radius:14px}
  body.present article{padding:20px 18px}
  article h1{font-size:24px}
  article h2{font-size:19px}
  .endnav,.foot{padding:0 14px}
  body.present .pageinfo{display:none}
  body.present main{display:block;height:auto;overflow:visible}
  body.present .stage{height:auto;overflow:visible;padding:12px 12px 40px}
  body.present article{height:auto;overflow:visible;padding:22px 18px}
  body.present .flow{height:auto}
}
@media print{
  body{background:#fff}
  aside,.bar,.endnav,.foot{display:none}
  .stage{padding:0}
  article{display:block!important;max-width:none;border:none;box-shadow:none;padding:0}
  article h2{break-after:avoid}
}
"""

JS = """
const chapters = [...document.querySelectorAll('article')];
const links = [...document.querySelectorAll('nav a.chap')];
const items = [...document.querySelectorAll('nav li')];
const prev = document.getElementById('prev');
const next = document.getElementById('next');
const crumb = document.getElementById('crumb-title');
const endPrev = document.getElementById('end-prev');
const endNext = document.getElementById('end-next');
const aside = document.querySelector('aside');
const pageinfo = document.getElementById('pageinfo');
const fsBtn = document.getElementById('fs');
let index = 0;
let page = 0, pageCount = 1, colW = 0, colGap = 0;

const isPresent = () => document.body.classList.contains('present');

function paint(i, syncHash) {
  index = Math.max(0, Math.min(chapters.length - 1, i));
  const art = chapters[index];
  chapters.forEach(a => a.classList.toggle('active', a === art));
  items.forEach(li => li.classList.toggle('active', li.dataset.key === art.dataset.key));
  links.forEach(a => {
    if (a.dataset.key === art.dataset.key) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
  crumb.textContent = art.dataset.label;
  if (syncHash && location.hash !== '#' + art.dataset.key) history.replaceState(null, '', '#' + art.dataset.key);
  try { localStorage.setItem('lecture-chapter', art.dataset.key); } catch (e) {}
}

/* ---- 分页：把一章的文字按屏幕高度切成若干「页」，横向平移翻页 ---- */
const narrow = () => window.innerWidth < 980;

function measure(keepPage) {
  const art = chapters[index];
  const flow = art.querySelector('.flow');
  if (!isPresent() || narrow()) {
    flow.style.transform = '';
    flow.style.columnWidth = '';
    pageinfo.textContent = '';
    updateButtons();
    return;
  }
  flow.style.transform = 'translateX(0)';
  flow.style.columnWidth = '';
  const w = flow.clientWidth;
  flow.style.columnWidth = w + 'px';
  const gap = parseFloat(getComputedStyle(flow).columnGap) || 0;
  void flow.offsetWidth;
  /* 矮表格整块不拆；比一页还高的表格才允许跨页拆行，避免整页空白 */
  const colH = flow.clientHeight;
  flow.querySelectorAll('.tw').forEach(w => {
    w.style.breakInside = (w.scrollHeight > colH - 24) ? 'auto' : 'avoid-column';
  });
  void flow.offsetWidth;
  const range = document.createRange();
  range.selectNodeContents(flow);
  let right = 0;
  for (const r of range.getClientRects()) if (r.right > right) right = r.right;
  const left = flow.getBoundingClientRect().left;
  const contentW = Math.max(w, right - left);
  colW = w; colGap = gap;
  pageCount = Math.max(1, Math.round((contentW + gap) / (w + gap)));
  page = keepPage ? Math.min(page, pageCount - 1) : 0;
  applyPage();
}

function applyPage() {
  const art = chapters[index];
  const flow = art.querySelector('.flow');
  if (!isPresent() || narrow()) return;
  flow.style.transform = 'translateX(' + (-page * (colW + colGap)) + 'px)';
  pageinfo.textContent = (page + 1) + ' / ' + pageCount;
  updateButtons();
}

function updateButtons() {
  if (isPresent()) {
    prev.textContent = narrow() ? '↑ 上一屏' : '← 上一页';
    next.textContent = narrow() ? '下一屏 ↓' : '下一页 →';
    prev.disabled = index === 0 && page === 0;
    next.disabled = index === chapters.length - 1 && page >= pageCount - 1;
  } else {
    prev.textContent = '← 上一章';
    next.textContent = '下一章 →';
    prev.disabled = index === 0;
    next.disabled = index === chapters.length - 1;
  }
  const before = chapters[index - 1], after = chapters[index + 1];
  endPrev.style.visibility = before ? 'visible' : 'hidden';
  endNext.style.visibility = after ? 'visible' : 'hidden';
  if (before) { endPrev.href = '#' + before.dataset.key; document.getElementById('end-prev-label').textContent = before.dataset.label; }
  if (after) { endNext.href = '#' + after.dataset.key; document.getElementById('end-next-label').textContent = after.dataset.label; }
}

function go(i) {
  paint(i, true);
  aside.classList.remove('open');
  page = 0;
  if (isPresent()) { measure(false); } else { window.scrollTo(0, 0); }
  updateButtons();
}

function step(delta) {
  if (!isPresent()) { go(index + delta); return; }
  if (narrow()) { window.scrollBy({ top: delta * window.innerHeight * 0.86, behavior: 'smooth' }); return; }
  const target = page + delta;
  if (target >= 0 && target < pageCount) { page = target; applyPage(); return; }
  if (target < 0 && index > 0) { paint(index - 1, true); measure(false); page = pageCount - 1; applyPage(); return; }
  if (target >= pageCount && index < chapters.length - 1) { paint(index + 1, true); measure(false); page = 0; applyPage(); }
}

links.forEach(a => a.addEventListener('click', e => { e.preventDefault(); go(+a.dataset.index); }));
prev.addEventListener('click', () => step(-1));
next.addEventListener('click', () => step(1));

/* 演示模式下点小节：定位到包含该标题的那一页 */
document.querySelectorAll('nav ol.sub a').forEach(a => a.addEventListener('click', e => {
  aside.classList.remove('open');
  if (!isPresent()) return;
  e.preventDefault();
  const id = decodeURIComponent(a.hash.slice(1));
  const el = document.getElementById(id);
  if (!el) return;
  const key = id.split('-')[0];
  const i = chapters.findIndex(c => c.dataset.key === key);
  if (i >= 0 && i !== index) paint(i, true);
  measure(false);
  const flow = chapters[index].querySelector('.flow');
  const x = el.getBoundingClientRect().left - flow.getBoundingClientRect().left;
  page = Math.max(0, Math.min(pageCount - 1, Math.floor(x / (colW + colGap))));
  applyPage();
}));

/* 全屏 */
function syncFs() { fsBtn.textContent = (document.fullscreenElement || isPresent()) ? '⤢ 退出全屏' : '⛶ 全屏'; }
async function toggleFs() {
  if (document.fullscreenElement) { await document.exitFullscreen(); return; }
  if (isPresent()) { document.body.classList.remove('present'); syncFs(); measure(false); return; }
  try { await document.documentElement.requestFullscreen(); }
  catch (e) { document.body.classList.add('present'); syncFs(); measure(false); }
}
fsBtn.addEventListener('click', toggleFs);
document.addEventListener('fullscreenchange', () => {
  document.body.classList.toggle('present', !!document.fullscreenElement);
  syncFs();
  requestAnimationFrame(() => measure(false));
});

document.getElementById('menu').addEventListener('click', () => aside.classList.toggle('open'));

document.addEventListener('keydown', e => {
  if (e.target.matches('input, textarea')) return;
  if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === ' ') { e.preventDefault(); step(1); }
  if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); step(-1); }
  if (e.key === 'f' || e.key === 'F') { e.preventDefault(); toggleFs(); }
  if (e.key === 'Escape' && isPresent() && !document.fullscreenElement) {
    document.body.classList.remove('present'); syncFs(); measure(false);
  }
});

/* 字号 */
const root = document.documentElement;
let size = 18;
try { const v = parseInt(localStorage.getItem('lecture-size'), 10); if (v >= 15 && v <= 26) size = v; } catch (e) {}
function applySize() {
  root.style.setProperty('--reading', size + 'px');
  try { localStorage.setItem('lecture-size', size); } catch (e) {}
  if (isPresent()) measure(true);
}
document.getElementById('font-down').addEventListener('click', () => { size = Math.max(15, size - 1); applySize(); });
document.getElementById('font-up').addEventListener('click', () => { size = Math.min(26, size + 1); applySize(); });
applySize();

let resizeTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { if (isPresent()) measure(true); }, 160);
});

function saved() {
  let v = null;
  try { v = localStorage.getItem('lecture-chapter'); } catch (e) {}
  const i = chapters.findIndex(a => a.dataset.key === v);
  return i >= 0 ? i : 0;
}
function fromHash() {
  const key = decodeURIComponent(location.hash.slice(1));
  if (!key) { paint(saved(), false); return; }
  const exact = chapters.findIndex(a => a.dataset.key === key);
  if (exact >= 0) { paint(exact, false); if (isPresent()) measure(false); window.scrollTo(0, 0); return; }
  const inner = chapters.findIndex(a => key.startsWith(a.dataset.key + '-'));
  if (inner >= 0) {
    paint(inner, false);
    if (isPresent()) measure(false);
    else { const el = document.getElementById(key); if (el) requestAnimationFrame(() => el.scrollIntoView({ block: 'start' })); }
    return;
  }
  paint(saved(), false);
}
window.addEventListener('hashchange', fromHash);
fromHash();
updateButtons();

const search = document.getElementById('search');
search.addEventListener('input', () => {
  const q = search.value.trim().toLowerCase();
  items.forEach(li => {
    const hay = (li.dataset.search || '') + ' ' + li.textContent;
    li.style.display = !q || hay.toLowerCase().includes(q) ? '' : 'none';
  });
});
"""


def bold_to_html(text: str) -> str:
    """中文里 `**加粗**` 紧贴标点时常不满足 CommonMark 的结尾条件，pandoc 会原样输出。
    这里先转成 <strong>；代码块保持原样，行内代码用占位符保护后再还原。"""
    blocks = re.split(r"(```.*?```)", text, flags=re.S)
    out = []
    for block in blocks:
        if block.startswith("```"):
            out.append(block)
            continue
        codes = []

        def hide(m):
            codes.append(m.group(0))
            return f"\x00{len(codes) - 1}\x00"

        tmp = re.sub(r"`[^`]*`", hide, block)
        tmp = re.sub(r"\*\*(?=\S)([^\n]*?\S)\*\*", r"<strong>\1</strong>", tmp)
        out.append(re.sub(r"\x00(\d+)\x00", lambda m: codes[int(m.group(1))], tmp))
    return "".join(out)


def pandoc_fragment(path: Path) -> str:
    text = bold_to_html(path.read_text(encoding="utf-8"))
    out = subprocess.run(
        ["pandoc", "-f", "gfm", "-t", "html", "--mathml", "--wrap=none"],
        input=text, capture_output=True, text=True, check=True,
    )
    return out.stdout


def embed_images(fragment: str) -> str:
    """把图片就地转成 data URI，使单文件可独立分发。"""
    def repl(m):
        src = html.unescape(m.group(1))
        target = (OUTPUT.parent / src).resolve()
        if not target.is_file() or target.stat().st_size > 3_000_000:
            return m.group(0)
        mime = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}.get(target.suffix.lower())
        if not mime:
            return m.group(0)
        data = base64.b64encode(target.read_bytes()).decode()
        return m.group(0).replace(m.group(1), f"data:{mime};base64,{data}")

    return re.sub(r'<img[^>]+src="([^"]+)"', repl, fragment)


def prefix_anchors(fragment: str, key: str) -> str:
    fragment = re.sub(r'\bid="([^"]+)"', lambda m: f'id="{key}-{m.group(1)}"', fragment)
    fragment = re.sub(r'href="#([^"]+)"', lambda m: f'href="#{key}-{m.group(1)}"', fragment)
    return fragment


def wrap_tables(fragment: str) -> str:
    return re.sub(r"<table>", '<div class="tw"><table>', fragment).replace("</table>", "</table></div>")


def headings(fragment: str) -> list[tuple[str, str]]:
    return [(m.group(1), re.sub(r"<[^>]+>", "", m.group(2))) for m in re.finditer(r'<h2 id="([^"]+)">(.*?)</h2>', fragment, re.S)]


def build(source: Path) -> str:
    articles, nav_items = [], []
    for i, (key, label, filename) in enumerate(CHAPTERS):
        path = source / filename
        if not path.is_file():
            raise SystemExit(f"找不到章节文件：{path}")
        fragment = prefix_anchors(pandoc_fragment(path), key)
        fragment = wrap_tables(embed_images(fragment))
        toc = headings(fragment)
        sub = "".join(f'<li><a href="#{hid}">{html.escape(text)}</a></li>' for hid, text in toc)
        nav_items.append(
            f'<li data-key="{key}" data-search="{html.escape(label)}">'
            f'<a class="chap" href="#{key}" data-key="{key}" data-index="{i}">{html.escape(label)}</a>'
            f'<ol class="sub">{sub}</ol></li>'
        )
        articles.append(
            f'<article data-key="{key}" data-label="{html.escape(label)}"><div class="flow">{fragment}</div></article>'
        )

    generated = datetime.now().strftime("%Y-%m-%d %H:%M")
    return f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>AI 时代的经济学实证研究 · 网页版</title>
<style>{CSS}</style></head><body>
<div class="layout">
  <aside>
    <div class="brand"><span class="brand-mark">经</span><b>AI 时代的经济学<br>实证研究</b></div>
    <div class="brand-sub">《中级计量经济学》研究实践讲义</div>
    <input id="search" class="search" type="search" placeholder="筛选章节或小节…" aria-label="筛选章节">
    <nav aria-label="章节目录"><h3>目录</h3><ol>{''.join(nav_items)}</ol></nav>
    <div class="side-foot">
      <a href="../../index.html">← 返回研究工作台</a>
      <a href="AI时代的经济学实证研究_完整讲义.pdf">下载 PDF 版</a>
      <span>← → 翻页 · F 全屏</span>
    </div>
  </aside>
  <main>
    <div class="bar">
      <button id="menu" type="button" aria-label="打开目录">☰ 目录</button>
      <span class="crumb"><a href="../../index.html">工作台</a> / 讲义 / <b id="crumb-title"></b></span>
      <span id="pageinfo" class="pageinfo"></span>
      <span class="tools">
        <button id="font-down" type="button" title="缩小字号">A−</button>
        <button id="font-up" type="button" title="放大字号">A+</button>
        <button id="fs" type="button" title="全屏演示（F）">⛶ 全屏</button>
      </span>
      <span class="pager">
        <button id="prev" type="button">← 上一章</button>
        <button id="next" type="button">下一章 →</button>
      </span>
    </div>
    <div class="stage">{''.join(articles)}</div>
    <div class="endnav">
      <a class="prev" href="#" id="end-prev"><small>上一章</small><span id="end-prev-label">—</span></a>
      <a class="next" href="#" id="end-next"><small>下一章</small><span id="end-next-label">—</span></a>
    </div>
    <p class="foot">由各章 Markdown 生成于 {generated}。正文与 PDF 版一致；公式以 MathML 呈现，图片已内嵌，离线可读。</p>
  </main>
</div>
<script>{JS}</script>
</body></html>
"""


def main() -> None:
    if shutil.which("pandoc") is None:
        sys.exit("需要 pandoc：brew install pandoc")
    source = Path(sys.argv[1]).expanduser() if len(sys.argv) > 1 else DEFAULT_SOURCE
    if not source.is_dir():
        sys.exit(f"找不到源码目录：{source}（可用参数指定）")
    OUTPUT.write_text(build(source), encoding="utf-8")
    print(f"已生成 {OUTPUT.relative_to(ROOT)}（{OUTPUT.stat().st_size / 1024:.0f} KB）")


if __name__ == "__main__":
    main()
